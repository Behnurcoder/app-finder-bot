import pytest
from utils.validators import (
    validate_app_title,
    validate_version_number,
    validate_file_name,
    validate_url,
)
from utils.helpers import slugify, format_file_size

def test_validate_app_title():
    ok, err = validate_app_title("Telegram")
    assert ok is True
    assert err is None

    ok_short, err_short = validate_app_title("A")
    assert ok_short is False
    assert "kamida 2 ta" in err_short

    ok_long, err_long = validate_app_title("A" * 105)
    assert ok_long is False
    assert "100 ta" in err_long

def test_validate_version_number():
    ok, err = validate_version_number("1.0.0")
    assert ok is True
    assert err is None

    ok_empty, err_empty = validate_version_number("")
    assert ok_empty is False

def test_validate_file_name():
    ok_apk, _ = validate_file_name("telegram.apk")
    assert ok_apk is True

    ok_zip, _ = validate_file_name("my_pack.zip")
    assert ok_zip is True

    ok_bad, err_bad = validate_file_name("malicious.bat")
    assert ok_bad is False
    assert "ruxsat etilmagan" in err_bad

def test_validate_url():
    assert validate_url("https://telegram.org/dl") is True
    assert validate_url("http://example.com/file.apk") is True
    assert validate_url("ftp://files.example.com") is True
    assert validate_url("invalid_url_text") is False

def test_slugify():
    assert slugify("Telegram Messenger") == "telegram-messenger"
    assert slugify("Instagram Rasmiy!") == "instagram-rasmiy"
    assert slugify("O'yinlar va Dasturlar") == "oyinlar-va-dasturlar"

def test_format_file_size():
    assert format_file_size(1024) == "1.0 KB"
    assert format_file_size(1024 * 1024 * 25) == "25.0 MB"
    assert format_file_size(0) == "Noma'lum"
