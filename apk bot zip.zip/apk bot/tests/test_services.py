import pytest
import pytest_asyncio
from sqlalchemy.ext.asyncio import create_async_engine, async_sessionmaker, AsyncSession
from database.models import Base
from database.repositories import UserRepository
from services.app_service import AppService
from services.support_service import SupportService
from services.statistics_service import StatisticsService
from services.channel_service import ChannelService

TEST_DB_URL = "sqlite+aiosqlite:///:memory:"

@pytest_asyncio.fixture
async def async_session():
    engine = create_async_engine(TEST_DB_URL, echo=False)
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

    session_factory = async_sessionmaker(engine, expire_on_commit=False, class_=AsyncSession)
    async with session_factory() as session:
        yield session

    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.drop_all)
    await engine.dispose()

@pytest.mark.asyncio
async def test_app_service_lifecycle(async_session: AsyncSession):
    app_service = AppService(async_session)

    # 1. Yangi ilova yaratish
    app = await app_service.create_app(
        title="Telegram Messenger",
        description="Tezkor va xavfsiz messenjer",
        category_id=None,
        platform="Android",
        photo_file_id=None,
        version_number="10.5.0",
        file_id="tg_file_id_example",
        file_size="65.2 MB",
        is_active=True
    )
    assert app.id is not None
    assert app.title == "Telegram Messenger"
    assert app.slug == "telegram-messenger"

    # 2. Yangi versiya qo'shish
    ver = await app_service.add_new_version(
        app_id=app.id,
        version_number="10.6.0",
        file_id="tg_new_file_id",
        file_size="68.0 MB",
        changelog="Xatoliklar tuzatildi"
    )
    assert ver.version_number == "10.6.0"
    assert ver.is_current is True

    # 3. Yuklab olishni qayd qilish
    await app_service.register_download(
        app_id=app.id,
        user_telegram_id=1234567,
        version="10.6.0"
    )
    updated_app = await app_service.get_app_details(app.id)
    assert updated_app.downloads_count == 1

    # 4. Yashirish va faollashtirish
    status = await app_service.toggle_app_status(app.id)
    assert status is False  # Yashirildi
    status = await app_service.toggle_app_status(app.id)
    assert status is True  # Qayta faollashtirildi

@pytest.mark.asyncio
async def test_statistics_service(async_session: AsyncSession):
    user_repo = UserRepository(async_session)
    await user_repo.register_or_update(telegram_id=101, first_name="User1")
    await user_repo.register_or_update(telegram_id=102, first_name="User2")
    await async_session.commit()

    stat_service = StatisticsService(async_session)
    stats = await stat_service.get_dashboard_stats()

    assert stats["total_users"] == 2
    assert stats["active_users"] == 2
    assert stats["total_apps"] == 0
    assert stats["total_tickets"] == 0

@pytest.mark.asyncio
async def test_support_service(async_session: AsyncSession):
    user_repo = UserRepository(async_session)
    await user_repo.register_or_update(telegram_id=555, first_name="Murojaat Egasi")
    await async_session.commit()

    sup_service = SupportService(async_session)

    # Chipta yaratish (bot obyektisiz test qilish uchun repo orqali)
    ticket = await sup_service.support_repo.create_ticket(
        user_id=555,
        subject="Ilova yuklab olinmayapti",
        initial_message="Yuklab olish tugmasi bosilganda xato bermoqda"
    )
    await async_session.commit()

    assert ticket.id is not None
    assert ticket.ticket_number.startswith("TICK-")
    assert ticket.status == "YANGI"

    # Chiptani yopish
    closed = await sup_service.close_ticket(ticket.id)
    assert closed is True

    reloaded = await sup_service.get_ticket(ticket.id)
    assert reloaded.status == "YOPILDI"
