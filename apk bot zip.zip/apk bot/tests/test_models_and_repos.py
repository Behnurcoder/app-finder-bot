import pytest
import pytest_asyncio
from sqlalchemy.ext.asyncio import create_async_engine, async_sessionmaker, AsyncSession
from database.models import Base
from database.repositories import (
    UserRepository,
    CategoryRepository,
    AppRepository,
    AdminRepository,
    ChannelRepository,
    SettingRepository,
    LogRepository,
)

TEST_DB_URL = "sqlite+aiosqlite:///:memory:"

@pytest_asyncio.fixture
async def async_session():
    engine = create_async_engine(TEST_DB_URL, echo=False)
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

    session_factory = async_sessionmaker(engine, expire_on_commit=False, class_=AsyncSession)
    async with session_factory() as session:
        yield session

    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.drop_all)
    await engine.dispose()

@pytest.mark.asyncio
async def test_user_repository(async_session: AsyncSession):
    repo = UserRepository(async_session)

    # Foydalanuvchi yaratish
    user = await repo.register_or_update(
        telegram_id=111222333,
        first_name="Ali",
        last_name="Valiyev",
        username="alivali"
    )
    await async_session.commit()

    assert user.id is not None
    assert user.telegram_id == 111222333
    assert user.first_name == "Ali"

    # Mavjud foydalanuvchini yangilash
    updated_user = await repo.register_or_update(
        telegram_id=111222333,
        first_name="Alisher"
    )
    await async_session.commit()
    assert updated_user.first_name == "Alisher"

    # Sanash
    total = await repo.count_total()
    assert total == 1

@pytest.mark.asyncio
async def test_category_repository(async_session: AsyncSession):
    repo = CategoryRepository(async_session)

    cat = await repo.create(name="Ijtimoiy tarmoqlar", slug="ijtimoiy-tarmoqlar", icon="💬")
    await async_session.commit()

    assert cat.id is not None
    assert cat.name == "Ijtimoiy tarmoqlar"

    all_active = await repo.get_all_active()
    assert len(all_active) == 1

@pytest.mark.asyncio
async def test_app_repository(async_session: AsyncSession):
    cat_repo = CategoryRepository(async_session)
    cat = await cat_repo.create(name="Dizayn", slug="dizayn", icon="🎨")
    await async_session.commit()

    app_repo = AppRepository(async_session)
    app = await app_repo.create(
        title="Canva",
        slug="canva",
        description="Grafik dizayn yaratish vositasi",
        category_id=cat.id,
        platform="Universal",
        initial_version="1.0.0",
        file_size="45 MB"
    )
    await async_session.commit()

    assert app.id is not None
    assert app.title == "Canva"

    app_with_ver = await app_repo.get_by_id(app.id)
    assert len(app_with_ver.versions) == 1
    assert app_with_ver.versions[0].version_number == "1.0.0"

    # Qidiruv
    results, count = await app_repo.search("canva")
    assert count == 1
    assert results[0].title == "Canva"

    # Yuklab olishlar sonini oshirish
    await app_repo.increment_downloads(app.id)
    await async_session.commit()

    reloaded_app = await app_repo.get_by_id(app.id)
    assert reloaded_app.downloads_count == 1

@pytest.mark.asyncio
async def test_admin_repository(async_session: AsyncSession):
    repo = AdminRepository(async_session)

    # Superadmin qo'shish
    superadmin = await repo.add_admin(
        telegram_id=999999,
        full_name="Bosh Admin",
        role="SUPERADMIN"
    )
    # Oddiy admin qo'shish
    admin = await repo.add_admin(
        telegram_id=888888,
        full_name="Yordamchi Admin",
        role="ADMIN"
    )
    await async_session.commit()

    assert await repo.is_superadmin(999999) is True
    assert await repo.is_admin(888888) is True
    assert await repo.is_superadmin(888888) is False

    # Superadminni o'chirish taqiqlangan
    deleted = await repo.remove_admin(999999)
    assert deleted is False

    # Oddiy adminni o'chirish mumkin
    deleted_admin = await repo.remove_admin(888888)
    assert deleted_admin is True

@pytest.mark.asyncio
async def test_channel_repository(async_session: AsyncSession):
    repo = ChannelRepository(async_session)

    channel = await repo.add_channel(
        title="Rasmiy Kanal",
        channel_id=-1001234567890,
        username="@rasmiykanal",
        channel_type="MANDATORY"
    )
    await async_session.commit()

    assert channel.id is not None
    active_channels = await repo.get_active_mandatory()
    assert len(active_channels) == 1
    assert active_channels[0].title == "Rasmiy Kanal"
