import asyncio
import logging
from typing import Dict, Any, Optional
from aiogram import Bot
from aiogram.exceptions import TelegramForbiddenError, TelegramRetryAfter, TelegramAPIError
from sqlalchemy.ext.asyncio import AsyncSession
from database.models import BroadcastMessage
from database.repositories import UserRepository

logger = logging.getLogger(__name__)

class BroadcastService:
    def __init__(self, session: AsyncSession):
        self.session = session
        self.user_repo = UserRepository(session)

    async def broadcast_to_all(
        self,
        bot: Bot,
        admin_telegram_id: int,
        text: str,
        photo_file_id: Optional[str] = None
    ) -> Dict[str, Any]:
        """Barcha faol foydalanuvchilarga xabar tarqatish."""
        user_ids = await self.user_repo.get_all_active_ids()
        total = len(user_ids)
        sent = 0
        failed = 0
        blocked = 0

        # Broadcast yozuvi yaratish
        bc_record = BroadcastMessage(
            admin_telegram_id=admin_telegram_id,
            message_type="photo" if photo_file_id else "text",
            content=text,
            photo_file_id=photo_file_id,
            total_target=total,
            status="PROCESSING"
        )
        self.session.add(bc_record)
        await self.session.commit()

        for user_id in user_ids:
            try:
                if photo_file_id:
                    await bot.send_photo(
                        chat_id=user_id,
                        photo=photo_file_id,
                        caption=text,
                        parse_mode="HTML"
                    )
                else:
                    await bot.send_message(
                        chat_id=user_id,
                        text=text,
                        parse_mode="HTML"
                    )
                sent += 1
            except TelegramForbiddenError:
                blocked += 1
                failed += 1
                await self.user_repo.mark_blocked(user_id)
            except TelegramRetryAfter as e:
                logger.warning(f"Telegram Flood Wait: {e.retry_after} soniya kutilmoqda...")
                await asyncio.sleep(e.retry_after)
                # Qayta urinish
                try:
                    if photo_file_id:
                        await bot.send_photo(chat_id=user_id, photo=photo_file_id, caption=text, parse_mode="HTML")
                    else:
                        await bot.send_message(chat_id=user_id, text=text, parse_mode="HTML")
                    sent += 1
                except Exception:
                    failed += 1
            except TelegramAPIError as e:
                logger.warning(f"Telegram API xatosi ({user_id}): {e}")
                failed += 1
            except Exception as e:
                logger.error(f"Xabar yuborishda noma'lum xato ({user_id}): {e}")
                failed += 1

            # Telegram limitlariga rioya qilish (soniyasiga ~25 xabar)
            await asyncio.sleep(0.04)

        # Natijalarni yangilash
        bc_record.sent_count = sent
        bc_record.failed_count = failed
        bc_record.status = "COMPLETED"
        await self.session.commit()

        return {
            "total": total,
            "sent": sent,
            "failed": failed,
            "blocked": blocked
        }

    async def send_to_single_user(
        self,
        bot: Bot,
        user_id: int,
        text: str,
        photo_file_id: Optional[str] = None
    ) -> bool:
        """Bitta foydalanuvchiga xabar yuborish."""
        try:
            if photo_file_id:
                await bot.send_photo(chat_id=user_id, photo=photo_file_id, caption=text, parse_mode="HTML")
            else:
                await bot.send_message(chat_id=user_id, text=text, parse_mode="HTML")
            return True
        except TelegramForbiddenError:
            await self.user_repo.mark_blocked(user_id)
            await self.session.commit()
            return False
        except Exception as e:
            logger.error(f"Foydalanuvchiga ({user_id}) xabar yuborishda xatolik: {e}")
            return False
