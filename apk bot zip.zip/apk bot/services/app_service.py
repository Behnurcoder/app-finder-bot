import logging
from typing import List, Optional, Tuple
from sqlalchemy.ext.asyncio import AsyncSession
from database.models import App, AppVersion, Category
from database.repositories import AppRepository, CategoryRepository, LogRepository
from utils.helpers import slugify

logger = logging.getLogger(__name__)

class AppService:
    def __init__(self, session: AsyncSession):
        self.session = session
        self.app_repo = AppRepository(session)
        self.cat_repo = CategoryRepository(session)
        self.log_repo = LogRepository(session)

    async def get_app_details(self, app_id: int) -> Optional[App]:
        return await self.app_repo.get_by_id(app_id)

    async def list_apps(self, page: int = 1, limit: int = 6, category_id: Optional[int] = None, only_active: bool = True) -> Tuple[List[App], int]:
        return await self.app_repo.get_all_paginated(page=page, limit=limit, category_id=category_id, only_active=only_active)

    async def search_apps(self, query: str, page: int = 1, limit: int = 6, only_active: bool = True) -> Tuple[List[App], int]:
        return await self.app_repo.search(query_str=query, page=page, limit=limit, only_active=only_active)

    async def get_popular_apps(self, limit: int = 6) -> List[App]:
        return await self.app_repo.get_popular(limit=limit)

    async def get_latest_apps(self, limit: int = 6) -> List[App]:
        return await self.app_repo.get_latest(limit=limit)

    async def register_download(self, app_id: int, user_telegram_id: int, version: Optional[str] = None, download_type: str = "TELEGRAM_FILE") -> None:
        await self.app_repo.increment_downloads(app_id)
        await self.log_repo.log_download(
            app_id=app_id,
            user_telegram_id=user_telegram_id,
            version=version,
            download_type=download_type
        )
        await self.session.commit()

    async def create_app(
        self,
        title: str,
        description: str,
        category_id: Optional[int],
        platform: str,
        photo_file_id: Optional[str],
        version_number: str,
        file_id: Optional[str] = None,
        download_url: Optional[str] = None,
        file_size: Optional[str] = None,
        is_active: bool = True,
    ) -> App:
        base_slug = slugify(title)
        slug = base_slug
        idx = 1
        while await self.app_repo.get_by_slug(slug):
            slug = f"{base_slug}-{idx}"
            idx += 1

        app = await self.app_repo.create(
            title=title,
            slug=slug,
            description=description,
            category_id=category_id,
            platform=platform,
            photo_file_id=photo_file_id,
            is_active=is_active,
            initial_version=version_number,
            file_id=file_id,
            download_url=download_url,
            file_size=file_size,
        )
        await self.session.commit()
        return app

    async def add_new_version(
        self,
        app_id: int,
        version_number: str,
        file_id: Optional[str] = None,
        download_url: Optional[str] = None,
        file_size: Optional[str] = None,
        changelog: Optional[str] = None,
    ) -> Optional[AppVersion]:
        app = await self.app_repo.get_by_id(app_id)
        if not app:
            return None
        ver = await self.app_repo.add_version(
            app_id=app_id,
            version_number=version_number,
            file_id=file_id,
            download_url=download_url,
            file_size=file_size,
            changelog=changelog,
        )
        await self.session.commit()
        return ver

    async def toggle_app_status(self, app_id: int) -> Optional[bool]:
        app = await self.app_repo.get_by_id(app_id)
        if not app:
            return None
        app.is_active = not app.is_active
        await self.session.commit()
        return app.is_active

    async def delete_app(self, app_id: int) -> bool:
        res = await self.app_repo.delete(app_id)
        if res:
            await self.session.commit()
        return res
