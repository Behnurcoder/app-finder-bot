from typing import Dict, Any, List
from sqlalchemy.ext.asyncio import AsyncSession
from database.repositories import (
    UserRepository,
    AppRepository,
    SupportRepository,
    AdminRepository,
    LogRepository,
)
from database.models import App

class StatisticsService:
    def __init__(self, session: AsyncSession):
        self.session = session
        self.user_repo = UserRepository(session)
        self.app_repo = AppRepository(session)
        self.support_repo = SupportRepository(session)
        self.admin_repo = AdminRepository(session)
        self.log_repo = LogRepository(session)

    async def get_dashboard_stats(self) -> Dict[str, Any]:
        """Admin panel uchun to'liq statistika ma'lumotlarini yig'adi."""
        total_users = await self.user_repo.count_total()
        today_users = await self.user_repo.count_today()
        active_users = await self.user_repo.count_active()

        total_apps = await self.app_repo.count_total()
        active_apps = await self.app_repo.count_active()

        total_downloads = await self.log_repo.count_total_downloads()
        top_apps: List[App] = await self.app_repo.get_popular(limit=5)

        total_tickets = await self.support_repo.count_total()
        unanswered_tickets = await self.support_repo.count_unanswered()

        total_admins = await self.admin_repo.count_total()

        return {
            "total_users": total_users,
            "today_users": today_users,
            "active_users": active_users,
            "total_apps": total_apps,
            "active_apps": active_apps,
            "total_downloads": total_downloads,
            "top_apps": top_apps,
            "total_tickets": total_tickets,
            "unanswered_tickets": unanswered_tickets,
            "total_admins": total_admins,
        }
