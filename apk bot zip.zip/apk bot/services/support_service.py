import logging
from typing import List, Optional, Tuple
from aiogram import Bot
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from sqlalchemy.ext.asyncio import AsyncSession
from database.models import SupportTicket, SupportMessage
from database.repositories import SupportRepository, AdminRepository
from utils.helpers import safe_html

logger = logging.getLogger(__name__)

class SupportService:
    def __init__(self, session: AsyncSession):
        self.session = session
        self.support_repo = SupportRepository(session)
        self.admin_repo = AdminRepository(session)

    async def submit_ticket(
        self,
        bot: Bot,
        user_id: int,
        user_name: str,
        subject: str,
        message_text: str
    ) -> SupportTicket:
        """Yangi murojaat yaratadi va adminlarga xabar beradi."""
        ticket = await self.support_repo.create_ticket(
            user_id=user_id,
            subject=subject,
            initial_message=message_text
        )
        await self.session.commit()

        # Adminlarga bildirishnoma yuborish
        admins = await self.admin_repo.get_all()
        notification_text = (
            f"📩 <b>Yangi murojaat qabul qilindi!</b>\n\n"
            f"🎫 <b>Chipta:</b> <code>{ticket.ticket_number}</code>\n"
            f"👤 <b>Foydalanuvchi:</b> {safe_html(user_name)} (<code>{user_id}</code>)\n"
            f"📌 <b>Mavzu:</b> {safe_html(subject)}\n"
            f"💬 <b>Xabar:</b>\n{safe_html(message_text)}"
        )
        reply_kb = InlineKeyboardMarkup(
            inline_keyboard=[[
                InlineKeyboardButton(
                    text="✍️ Javob berish",
                    callback_data=f"adm_reply_ticket_{ticket.id}"
                )
            ]]
        )

        for admin in admins:
            if admin.is_active:
                try:
                    await bot.send_message(
                        chat_id=admin.telegram_id,
                        text=notification_text,
                        parse_mode="HTML",
                        reply_markup=reply_kb
                    )
                except Exception as e:
                    logger.warning(f"Adminga ({admin.telegram_id}) murojaat xabarnomasini yuborishda xatolik: {e}")

        return ticket

    async def send_reply(
        self,
        bot: Bot,
        ticket_id: int,
        admin_id: int,
        reply_text: str
    ) -> Tuple[bool, Optional[str]]:
        """Admin javobini foydalanuvchiga yuboradi va statusni yangilaydi."""
        ticket = await self.support_repo.get_by_id(ticket_id)
        if not ticket:
            return False, "Chipta topilmadi."

        await self.support_repo.add_reply(
            ticket_id=ticket_id,
            sender_type="ADMIN",
            sender_id=admin_id,
            text=reply_text
        )
        await self.session.commit()

        # Foydalanuvchiga yuborish
        user_msg = (
            f"📬 <b>Sizning murojaatingizga javob keldi!</b>\n\n"
            f"🎫 <b>Chipta raqami:</b> <code>{ticket.ticket_number}</code>\n"
            f"📌 <b>Mavzu:</b> {safe_html(ticket.subject)}\n\n"
            f"👨‍💻 <b>Admin javobi:</b>\n"
            f"{safe_html(reply_text)}\n\n"
            f"<i>Savollaringiz bo'lsa, qayta murojaat qilishingiz mumkin.</i>"
        )
        try:
            await bot.send_message(
                chat_id=ticket.user_id,
                text=user_msg,
                parse_mode="HTML"
            )
            return True, None
        except Exception as e:
            logger.error(f"Foydalanuvchiga ({ticket.user_id}) javob yuborishda xatolik: {e}")
            return False, f"Xabar foydalanuvchiga yetkazilmadi (bot bloklangan bo'lishi mumkin): {e}"

    async def close_ticket(self, ticket_id: int) -> bool:
        res = await self.support_repo.update_status(ticket_id, "YOPILDI")
        if res:
            await self.session.commit()
        return res

    async def get_tickets(self, page: int = 1, limit: int = 8, status: Optional[str] = None) -> Tuple[List[SupportTicket], int]:
        return await self.support_repo.get_all_paginated(page=page, limit=limit, status=status)

    async def get_ticket(self, ticket_id: int) -> Optional[SupportTicket]:
        return await self.support_repo.get_by_id(ticket_id)
