import logging
from typing import List, Tuple
from aiogram import Bot
from aiogram.exceptions import TelegramAPIError
from sqlalchemy.ext.asyncio import AsyncSession
from database.models import Channel
from database.repositories import ChannelRepository, SettingRepository

logger = logging.getLogger(__name__)

class ChannelService:
    def __init__(self, session: AsyncSession):
        self.session = session
        self.channel_repo = ChannelRepository(session)
        self.setting_repo = SettingRepository(session)

    async def check_user_subscription(self, bot: Bot, user_id: int) -> Tuple[bool, List[Channel]]:
        """
        Foydalanuvchining majburiy kanallarga a'zoligini tekshiradi.
        Qaytaradi: (barchasiga a'zo bo'lganmi?, a'zo bo'linmagan kanallar ro'yxati)
        """
        # Majburiy obuna sozlamasini tekshirish
        is_sub_enabled = await self.setting_repo.get("mandatory_subscription", "true")
        if is_sub_enabled.lower() not in ("true", "1", "yes"):
            return True, []

        channels = await self.channel_repo.get_active_mandatory()
        if not channels:
            return True, []

        unsubscribed_channels: List[Channel] = []

        for channel in channels:
            try:
                member = await bot.get_chat_member(chat_id=channel.channel_id, user_id=user_id)
                # Foydalanuvchi statusi: creator, administrator, member, restricted (is_member=True)
                if member.status in ("left", "kicked"):
                    unsubscribed_channels.append(channel)
            except TelegramAPIError as e:
                logger.warning(
                    f"Kanal obunasini tekshirishda xatolik (Kanal: {channel.channel_id}, User: {user_id}): {e}"
                )
                # Agar bot kanalda a'zo/admin bo'lmasa, foydalanuvchini nohaq to'xtatib qo'ymaslik uchun o'tkazib yuboramiz
                continue
            except Exception as e:
                logger.error(f"Kutilmagan obuna tekshirish xatosi: {e}")
                continue

        return len(unsubscribed_channels) == 0, unsubscribed_channels

    async def get_all_channels(self) -> List[Channel]:
        return await self.channel_repo.get_all()

    async def add_channel(
        self,
        title: str,
        channel_id: int,
        username: str | None = None,
        invite_link: str | None = None,
        channel_type: str = "MANDATORY"
    ) -> Channel:
        channel = await self.channel_repo.add_channel(
            title=title,
            channel_id=channel_id,
            username=username,
            invite_link=invite_link,
            channel_type=channel_type
        )
        await self.session.commit()
        return channel

    async def toggle_channel(self, channel_id: int) -> bool | None:
        res = await self.channel_repo.toggle_status(channel_id)
        if res is not None:
            await self.session.commit()
        return res

    async def delete_channel(self, channel_id: int) -> bool:
        res = await self.channel_repo.delete(channel_id)
        if res:
            await self.session.commit()
        return res
