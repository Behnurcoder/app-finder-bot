from aiogram.fsm.state import State, StatesGroup

class AddAppStates(StatesGroup):
    waiting_for_title = State()
    waiting_for_version = State()
    waiting_for_description = State()
    waiting_for_category = State()
    waiting_for_photo = State()
    waiting_for_file_or_url = State()
    waiting_for_size = State()
    waiting_for_platform = State()
    waiting_for_status = State()
    confirmation = State()

class EditAppStates(StatesGroup):
    select_app = State()
    select_field = State()
    waiting_for_new_value = State()

class AddVersionStates(StatesGroup):
    waiting_for_version_number = State()
    waiting_for_file_or_url = State()
    waiting_for_size = State()
    waiting_for_changelog = State()
    confirmation = State()

class ManageAdminStates(StatesGroup):
    waiting_for_admin_id = State()
    waiting_for_name = State()
    waiting_for_username = State()
    select_role = State()

class ManageChannelStates(StatesGroup):
    waiting_for_title = State()
    waiting_for_channel_id = State()
    waiting_for_username = State()
    waiting_for_link = State()
    select_type = State()

class ManageCategoryStates(StatesGroup):
    waiting_for_name = State()
    waiting_for_icon = State()

class BroadcastStates(StatesGroup):
    select_type = State()  # all yoki single
    waiting_for_target_id = State()
    waiting_for_content = State()
    waiting_for_photo = State()
    confirmation = State()

class SupportReplyStates(StatesGroup):
    waiting_for_reply_text = State()
