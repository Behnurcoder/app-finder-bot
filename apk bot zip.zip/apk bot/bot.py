import asyncio
import logging
import sys
from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.fsm.storage.redis import RedisStorage

from config import config
from database.database import init_db, engine
from handlers import main_router
from middlewares import DbSessionMiddleware

# Logging sozlamalari
logging.basicConfig(
    level=getattr(logging, config.LOG_LEVEL.upper(), logging.INFO),
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers=[
        logging.StreamHandler(sys.stdout),
    ],
)
logger = logging.getLogger(__name__)

async def on_startup(bot: Bot) -> None:
    """Bot ishga tushganda bajariladigan amallar."""
    logger.info("Ma'lumotlar bazasi initsializatsiya qilinmoqda...")
    await init_db()
    logger.info("Ma'lumotlar bazasi tayyor.")

    # Superadminga xabar yuborish
    if config.SUPERADMIN_ID > 0:
        try:
            bot_info = await bot.get_me()
            await bot.send_message(
                chat_id=config.SUPERADMIN_ID,
                text=f"🚀 <b>App Finder Bot muvaffaqiyatli ishga tushdi!</b>\n\n"
                     f"🤖 Bot: @{bot_info.username}\n"
                     f"📊 Holati: Faol va so'rovlarni qabul qilishga tayyor.",
                parse_mode=ParseMode.HTML
            )
            logger.info(f"Superadmin ({config.SUPERADMIN_ID}) ga ishga tushish xabarnomasi yuborildi.")
        except Exception as e:
            logger.warning(f"Superadminga startup xabarnomasini yuborishda xatolik: {e}")

async def on_shutdown(bot: Bot) -> None:
    """Bot to'xtaganda bajariladigan amallar."""
    logger.info("Bot to'xtatilmoqda...")
    await engine.dispose()
    logger.info("Ma'lumotlar bazasi ulanishlari yopildi.")

async def main() -> None:
    """Asosiy ishga tushirish funksiyasi."""
    if not config.BOT_TOKEN:
        logger.critical("XATOLIK: BOT_TOKEN ko'rsatilmagan! Iltimos .env faylini to'ldiring.")
        return

    # FSM Storage tanlash
    if config.USE_REDIS and config.REDIS_URL:
        try:
            storage = RedisStorage.from_url(config.REDIS_URL)
            logger.info("FSM uchun Redis storage tanlandi.")
        except Exception as e:
            logger.warning(f"Redis ulanishida xatolik: {e}. MemoryStorage ga o'tildi.")
            storage = MemoryStorage()
    else:
        storage = MemoryStorage()
        logger.info("FSM uchun MemoryStorage tanlandi.")

    bot = Bot(
        token=config.BOT_TOKEN,
        default=DefaultBotProperties(parse_mode=ParseMode.HTML),
    )
    dp = Dispatcher(storage=storage)

    # Middlewarelarni ro'yxatdan o'tkazish
    dp.update.middleware(DbSessionMiddleware())

    # Routerni ulash
    dp.include_router(main_router)

    # Startup va Shutdown hodisalari
    dp.startup.register(on_startup)
    dp.shutdown.register(on_shutdown)

    # Eski kutilayotgan yangilanishlarni (updates) tozalash
    await bot.delete_webhook(drop_pending_updates=True)

    logger.info("Bot long-polling orqali ishga tushmoqda...")
    try:
        await dp.start_polling(bot, allowed_updates=dp.resolve_used_update_types())
    finally:
        await bot.session.close()

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except (KeyboardInterrupt, SystemExit):
        logger.info("Bot qo'lda to'xtatildi.")
