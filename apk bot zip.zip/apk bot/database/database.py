import logging
from contextlib import asynccontextmanager
from typing import AsyncGenerator
from sqlalchemy.ext.asyncio import (
    AsyncEngine,
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)
from sqlalchemy import select
from config import config
from database.models import Base, Category, Admin, BotSetting

logger = logging.getLogger(__name__)

# Engine yaratish
engine: AsyncEngine = create_async_engine(
    config.DATABASE_URL,
    echo=False,
    future=True,
    pool_pre_ping=True,
)

# Async session factory
AsyncSessionFactory = async_sessionmaker(
    bind=engine,
    class_=AsyncSession,
    expire_on_commit=False,
    autoflush=False,
)

@asynccontextmanager
async def get_db_session() -> AsyncGenerator[AsyncSession, None]:
    """Database sessiyasini context manager orqali xavfsiz boshqarish."""
    async with AsyncSessionFactory() as session:
        try:
            yield session
            await session.commit()
        except Exception as e:
            await session.rollback()
            logger.error(f"Database session xatoligi: {e}", exc_info=True)
            raise
        finally:
            await session.close()

async def init_db() -> None:
    """Ma'lumotlar bazasini initsializatsiya qilish va boshlang'ich ma'lumotlarni kiritish."""
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    logger.info("Ma'lumotlar bazasi jadvallari muvaffaqiyatli tekshirildi/yaratildi.")

    # Dastlabki ma'lumotlarni (seed) kiritish
    async with AsyncSessionFactory() as session:
        # 1. Boshlang'ich kategoriyalar
        default_categories = [
            ("Ijtimoiy tarmoqlar", "ijtimoiy-tarmoqlar", "💬"),
            ("Video montaj", "video-montaj", "🎬"),
            ("Ta'lim", "talim", "📚"),
            ("Dizayn", "dizayn", "🎨"),
            ("Foydali dasturlar", "foydali-dasturlar", "🛠"),
            ("O‘yinlar", "oyinlar", "🎮"),
            ("Boshqa ilovalar", "boshqa-ilovalar", "📦"),
        ]
        for name, slug, icon in default_categories:
            result = await session.execute(select(Category).where(Category.slug == slug))
            if not result.scalar_one_or_none():
                session.add(Category(name=name, slug=slug, icon=icon, is_active=True))

        # 2. Superadminni tekshirish va qo'shish
        if config.SUPERADMIN_ID > 0:
            result = await session.execute(select(Admin).where(Admin.telegram_id == config.SUPERADMIN_ID))
            superadmin = result.scalar_one_or_none()
            if not superadmin:
                session.add(Admin(
                    telegram_id=config.SUPERADMIN_ID,
                    full_name="Bosh Administrator",
                    username="superadmin",
                    role="SUPERADMIN",
                    is_active=True,
                    permissions="all",
                ))
                logger.info(f"Superadmin (ID: {config.SUPERADMIN_ID}) bazaga qo'shildi.")

        # 3. Birlamchi bot sozlamalari
        default_settings = [
            ("mandatory_subscription", "true", "Majburiy obuna tekshiruvi yoqilgan/o'chirilgan"),
            ("maintenance_mode", "false", "Texnik tanaffus rejimi"),
            ("about_text", (
                "📱 **App Finder Bot** — eng sara va foydali ilovalar katalogi!\n\n"
                "Ushbu bot orqali siz kerakli ilovalarni tez va oson topishingiz, "
                "kategoriyalar bo'yicha ko'rishingiz va xavfsiz yuklab olishingiz mumkin.\n\n"
                "Barcha ilovalar tekshirilgan va xavfsiz manbalardan olingan."
            ), "Bot haqida matni"),
        ]
        for key, value, desc in default_settings:
            result = await session.execute(select(BotSetting).where(BotSetting.key == key))
            if not result.scalar_one_or_none():
                session.add(BotSetting(key=key, value=value, description=desc))

        await session.commit()
    logger.info("Boshlang'ich konfiguratsiya ma'lumotlari tekshirildi.")
