import logging
from datetime import datetime, date, timezone
from typing import List, Optional, Tuple
from sqlalchemy import select, update, delete, func, desc, or_
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from database.models import (
    User,
    Category,
    App,
    AppVersion,
    Admin,
    Channel,
    SupportTicket,
    SupportMessage,
    BroadcastMessage,
    DownloadLog,
    AdminActivityLog,
    BotSetting,
    utc_now,
)

logger = logging.getLogger(__name__)


class UserRepository:
    def __init__(self, session: AsyncSession):
        self.session = session

    async def register_or_update(
        self,
        telegram_id: int,
        first_name: str,
        last_name: Optional[str] = None,
        username: Optional[str] = None,
        language_code: str = "uz"
    ) -> User:
        result = await self.session.execute(select(User).where(User.telegram_id == telegram_id))
        user = result.scalar_one_or_none()
        if user:
            user.first_name = first_name
            user.last_name = last_name
            user.username = username
            user.is_blocked_by_bot = False
            user.updated_at = utc_now()
        else:
            user = User(
                telegram_id=telegram_id,
                first_name=first_name,
                last_name=last_name,
                username=username,
                language_code=language_code,
                is_active=True,
                is_blocked_by_bot=False
            )
            self.session.add(user)
        return user

    async def get_by_telegram_id(self, telegram_id: int) -> Optional[User]:
        result = await self.session.execute(select(User).where(User.telegram_id == telegram_id))
        return result.scalar_one_or_none()

    async def mark_blocked(self, telegram_id: int) -> None:
        await self.session.execute(
            update(User).where(User.telegram_id == telegram_id).values(is_blocked_by_bot=True)
        )

    async def get_all_active_ids(self) -> List[int]:
        result = await self.session.execute(
            select(User.telegram_id).where(User.is_active.is_(True), User.is_blocked_by_bot.is_(False))
        )
        return [row[0] for row in result.all()]

    async def count_total(self) -> int:
        result = await self.session.execute(select(func.count(User.id)))
        return result.scalar_one() or 0

    async def count_today(self) -> int:
        today_start = datetime.combine(date.today(), datetime.min.time())
        result = await self.session.execute(
            select(func.count(User.id)).where(User.created_at >= today_start)
        )
        return result.scalar_one() or 0

    async def count_active(self) -> int:
        result = await self.session.execute(
            select(func.count(User.id)).where(User.is_active.is_(True), User.is_blocked_by_bot.is_(False))
        )
        return result.scalar_one() or 0


class CategoryRepository:
    def __init__(self, session: AsyncSession):
        self.session = session

    async def get_all_active(self) -> List[Category]:
        result = await self.session.execute(
            select(Category).where(Category.is_active.is_(True)).order_by(Category.id)
        )
        return list(result.scalars().all())

    async def get_all(self) -> List[Category]:
        result = await self.session.execute(select(Category).order_by(Category.id))
        return list(result.scalars().all())

    async def get_by_id(self, category_id: int) -> Optional[Category]:
        result = await self.session.execute(select(Category).where(Category.id == category_id))
        return result.scalar_one_or_none()

    async def create(self, name: str, slug: str, icon: str = "📁") -> Category:
        category = Category(name=name, slug=slug, icon=icon, is_active=True)
        self.session.add(category)
        return category

    async def update(self, category_id: int, name: Optional[str] = None, icon: Optional[str] = None, is_active: Optional[bool] = None) -> Optional[Category]:
        category = await self.get_by_id(category_id)
        if not category:
            return None
        if name is not None:
            category.name = name
        if icon is not None:
            category.icon = icon
        if is_active is not None:
            category.is_active = is_active
        return category

    async def delete(self, category_id: int) -> bool:
        category = await self.get_by_id(category_id)
        if not category:
            return False
        await self.session.delete(category)
        return True


class AppRepository:
    def __init__(self, session: AsyncSession):
        self.session = session

    async def get_by_id(self, app_id: int) -> Optional[App]:
        result = await self.session.execute(
            select(App)
            .options(selectinload(App.category), selectinload(App.versions))
            .where(App.id == app_id)
        )
        return result.scalar_one_or_none()

    async def get_by_slug(self, slug: str) -> Optional[App]:
        result = await self.session.execute(
            select(App)
            .options(selectinload(App.category), selectinload(App.versions))
            .where(App.slug == slug)
        )
        return result.scalar_one_or_none()

    async def create(
        self,
        title: str,
        slug: str,
        description: str,
        category_id: Optional[int] = None,
        platform: str = "Android",
        photo_file_id: Optional[str] = None,
        is_active: bool = True,
        initial_version: Optional[str] = None,
        file_id: Optional[str] = None,
        download_url: Optional[str] = None,
        file_size: Optional[str] = None,
    ) -> App:
        app = App(
            title=title,
            slug=slug,
            description=description,
            category_id=category_id,
            platform=platform,
            photo_file_id=photo_file_id,
            is_active=is_active,
            downloads_count=0,
        )
        self.session.add(app)
        await self.session.flush()

        if initial_version:
            version = AppVersion(
                app_id=app.id,
                version_number=initial_version,
                file_id=file_id,
                download_url=download_url,
                file_size=file_size,
                is_current=True,
            )
            self.session.add(version)

        return app

    async def add_version(
        self,
        app_id: int,
        version_number: str,
        file_id: Optional[str] = None,
        download_url: Optional[str] = None,
        file_size: Optional[str] = None,
        changelog: Optional[str] = None,
    ) -> AppVersion:
        # Eski joriy versiyalarni is_current=False qilish
        await self.session.execute(
            update(AppVersion).where(AppVersion.app_id == app_id).values(is_current=False)
        )
        new_version = AppVersion(
            app_id=app_id,
            version_number=version_number,
            file_id=file_id,
            download_url=download_url,
            file_size=file_size,
            changelog=changelog,
            is_current=True,
        )
        self.session.add(new_version)
        # Ilovaning updated_at ni yangilash
        await self.session.execute(
            update(App).where(App.id == app_id).values(updated_at=utc_now())
        )
        return new_version

    async def update(self, app_id: int, **kwargs) -> Optional[App]:
        app = await self.get_by_id(app_id)
        if not app:
            return None
        for key, value in kwargs.items():
            if hasattr(app, key) and value is not None:
                setattr(app, key, value)
        app.updated_at = utc_now()
        return app

    async def delete(self, app_id: int) -> bool:
        app = await self.get_by_id(app_id)
        if not app:
            return False
        await self.session.delete(app)
        return True

    async def get_all_paginated(
        self,
        page: int = 1,
        limit: int = 6,
        category_id: Optional[int] = None,
        only_active: bool = True
    ) -> Tuple[List[App], int]:
        query = select(App).options(selectinload(App.category), selectinload(App.versions))
        count_query = select(func.count(App.id))

        if only_active:
            query = query.where(App.is_active.is_(True))
            count_query = count_query.where(App.is_active.is_(True))

        if category_id:
            query = query.where(App.category_id == category_id)
            count_query = count_query.where(App.category_id == category_id)

        query = query.order_by(desc(App.created_at)).offset((page - 1) * limit).limit(limit)

        result = await self.session.execute(query)
        apps = list(result.scalars().all())

        count_result = await self.session.execute(count_query)
        total = count_result.scalar_one() or 0

        return apps, total

    async def search(self, query_str: str, page: int = 1, limit: int = 6, only_active: bool = True) -> Tuple[List[App], int]:
        pattern = f"%{query_str.strip()}%"
        query = (
            select(App)
            .options(selectinload(App.category), selectinload(App.versions))
            .where(or_(App.title.ilike(pattern), App.description.ilike(pattern)))
        )
        count_query = select(func.count(App.id)).where(
            or_(App.title.ilike(pattern), App.description.ilike(pattern))
        )

        if only_active:
            query = query.where(App.is_active.is_(True))
            count_query = count_query.where(App.is_active.is_(True))

        query = query.order_by(desc(App.downloads_count)).offset((page - 1) * limit).limit(limit)

        result = await self.session.execute(query)
        apps = list(result.scalars().all())

        count_result = await self.session.execute(count_query)
        total = count_result.scalar_one() or 0

        return apps, total

    async def get_popular(self, limit: int = 6) -> List[App]:
        result = await self.session.execute(
            select(App)
            .options(selectinload(App.category), selectinload(App.versions))
            .where(App.is_active.is_(True))
            .order_by(desc(App.downloads_count), desc(App.created_at))
            .limit(limit)
        )
        return list(result.scalars().all())

    async def get_latest(self, limit: int = 6) -> List[App]:
        result = await self.session.execute(
            select(App)
            .options(selectinload(App.category), selectinload(App.versions))
            .where(App.is_active.is_(True))
            .order_by(desc(App.created_at))
            .limit(limit)
        )
        return list(result.scalars().all())

    async def increment_downloads(self, app_id: int) -> None:
        await self.session.execute(
            update(App).where(App.id == app_id).values(downloads_count=App.downloads_count + 1)
        )

    async def count_total(self) -> int:
        result = await self.session.execute(select(func.count(App.id)))
        return result.scalar_one() or 0

    async def count_active(self) -> int:
        result = await self.session.execute(
            select(func.count(App.id)).where(App.is_active.is_(True))
        )
        return result.scalar_one() or 0


class AdminRepository:
    def __init__(self, session: AsyncSession):
        self.session = session

    async def get_by_telegram_id(self, telegram_id: int) -> Optional[Admin]:
        result = await self.session.execute(
            select(Admin).where(Admin.telegram_id == telegram_id, Admin.is_active.is_(True))
        )
        return result.scalar_one_or_none()

    async def is_admin(self, telegram_id: int) -> bool:
        admin = await self.get_by_telegram_id(telegram_id)
        return admin is not None and admin.is_active

    async def is_superadmin(self, telegram_id: int) -> bool:
        admin = await self.get_by_telegram_id(telegram_id)
        return admin is not None and admin.is_active and admin.role == "SUPERADMIN"

    async def get_all(self) -> List[Admin]:
        result = await self.session.execute(select(Admin).order_by(Admin.id))
        return list(result.scalars().all())

    async def add_admin(
        self,
        telegram_id: int,
        full_name: str,
        username: Optional[str] = None,
        role: str = "ADMIN",
        permissions: str = "all"
    ) -> Admin:
        result = await self.session.execute(select(Admin).where(Admin.telegram_id == telegram_id))
        existing = result.scalar_one_or_none()
        if existing:
            existing.full_name = full_name
            existing.username = username
            existing.role = role
            existing.is_active = True
            existing.permissions = permissions
            return existing
        new_admin = Admin(
            telegram_id=telegram_id,
            full_name=full_name,
            username=username,
            role=role,
            is_active=True,
            permissions=permissions
        )
        self.session.add(new_admin)
        return new_admin

    async def remove_admin(self, telegram_id: int) -> bool:
        result = await self.session.execute(select(Admin).where(Admin.telegram_id == telegram_id))
        admin = result.scalar_one_or_none()
        if not admin or admin.role == "SUPERADMIN":
            return False
        await self.session.delete(admin)
        return True

    async def toggle_status(self, telegram_id: int) -> Optional[bool]:
        result = await self.session.execute(select(Admin).where(Admin.telegram_id == telegram_id))
        admin = result.scalar_one_or_none()
        if not admin or admin.role == "SUPERADMIN":
            return None
        admin.is_active = not admin.is_active
        return admin.is_active

    async def count_total(self) -> int:
        result = await self.session.execute(
            select(func.count(Admin.id)).where(Admin.is_active.is_(True))
        )
        return result.scalar_one() or 0


class ChannelRepository:
    def __init__(self, session: AsyncSession):
        self.session = session

    async def get_all(self) -> List[Channel]:
        result = await self.session.execute(select(Channel).order_by(Channel.id))
        return list(result.scalars().all())

    async def get_active_mandatory(self) -> List[Channel]:
        result = await self.session.execute(
            select(Channel).where(
                Channel.is_active.is_(True),
                Channel.channel_type.in_(["MANDATORY", "REQUEST"])
            )
        )
        return list(result.scalars().all())

    async def get_by_id(self, channel_db_id: int) -> Optional[Channel]:
        result = await self.session.execute(select(Channel).where(Channel.id == channel_db_id))
        return result.scalar_one_or_none()

    async def get_by_telegram_channel_id(self, channel_id: int) -> Optional[Channel]:
        result = await self.session.execute(select(Channel).where(Channel.channel_id == channel_id))
        return result.scalar_one_or_none()

    async def add_channel(
        self,
        title: str,
        channel_id: int,
        username: Optional[str] = None,
        invite_link: Optional[str] = None,
        channel_type: str = "MANDATORY"
    ) -> Channel:
        channel = Channel(
            title=title,
            channel_id=channel_id,
            username=username,
            invite_link=invite_link,
            channel_type=channel_type,
            is_active=True
        )
        self.session.add(channel)
        return channel

    async def delete(self, channel_db_id: int) -> bool:
        channel = await self.get_by_id(channel_db_id)
        if not channel:
            return False
        await self.session.delete(channel)
        return True

    async def toggle_status(self, channel_db_id: int) -> Optional[bool]:
        channel = await self.get_by_id(channel_db_id)
        if not channel:
            return None
        channel.is_active = not channel.is_active
        return channel.is_active


class SupportRepository:
    def __init__(self, session: AsyncSession):
        self.session = session

    async def create_ticket(self, user_id: int, subject: str, initial_message: str) -> SupportTicket:
        ticket_number = f"TICK-{int(utc_now().timestamp())}"
        ticket = SupportTicket(
            ticket_number=ticket_number,
            user_id=user_id,
            subject=subject,
            status="YANGI"
        )
        self.session.add(ticket)
        await self.session.flush()

        msg = SupportMessage(
            ticket_id=ticket.id,
            sender_type="USER",
            sender_telegram_id=user_id,
            message_text=initial_message
        )
        self.session.add(msg)
        return ticket

    async def add_reply(self, ticket_id: int, sender_type: str, sender_id: int, text: str) -> SupportMessage:
        msg = SupportMessage(
            ticket_id=ticket_id,
            sender_type=sender_type,
            sender_telegram_id=sender_id,
            message_text=text
        )
        self.session.add(msg)
        
        status_update = "JAVOB_BERILDI" if sender_type == "ADMIN" else "KO'RIB_CHIQILMOQDA"
        await self.session.execute(
            update(SupportTicket)
            .where(SupportTicket.id == ticket_id)
            .values(status=status_update, updated_at=utc_now())
        )
        return msg

    async def get_by_id(self, ticket_id: int) -> Optional[SupportTicket]:
        result = await self.session.execute(
            select(SupportTicket)
            .options(selectinload(SupportTicket.messages), selectinload(SupportTicket.user))
            .where(SupportTicket.id == ticket_id)
        )
        return result.scalar_one_or_none()

    async def get_all_paginated(self, page: int = 1, limit: int = 10, status: Optional[str] = None) -> Tuple[List[SupportTicket], int]:
        query = select(SupportTicket).options(selectinload(SupportTicket.user))
        count_query = select(func.count(SupportTicket.id))

        if status:
            query = query.where(SupportTicket.status == status)
            count_query = count_query.where(SupportTicket.status == status)

        query = query.order_by(desc(SupportTicket.updated_at)).offset((page - 1) * limit).limit(limit)

        result = await self.session.execute(query)
        tickets = list(result.scalars().all())

        count_result = await self.session.execute(count_query)
        total = count_result.scalar_one() or 0

        return tickets, total

    async def update_status(self, ticket_id: int, status: str) -> bool:
        ticket = await self.get_by_id(ticket_id)
        if not ticket:
            return False
        ticket.status = status
        ticket.updated_at = utc_now()
        return True

    async def count_total(self) -> int:
        result = await self.session.execute(select(func.count(SupportTicket.id)))
        return result.scalar_one() or 0

    async def count_unanswered(self) -> int:
        result = await self.session.execute(
            select(func.count(SupportTicket.id)).where(
                SupportTicket.status.in_(["YANGI", "KO'RIB_CHIQILMOQDA"])
            )
        )
        return result.scalar_one() or 0


class SettingRepository:
    def __init__(self, session: AsyncSession):
        self.session = session

    async def get(self, key: str, default: str = "") -> str:
        result = await self.session.execute(select(BotSetting.value).where(BotSetting.key == key))
        val = result.scalar_one_or_none()
        return val if val is not None else default

    async def set(self, key: str, value: str, description: Optional[str] = None) -> None:
        result = await self.session.execute(select(BotSetting).where(BotSetting.key == key))
        setting = result.scalar_one_or_none()
        if setting:
            setting.value = value
            if description:
                setting.description = description
            setting.updated_at = utc_now()
        else:
            self.session.add(BotSetting(key=key, value=value, description=description))

    async def get_all(self) -> List[BotSetting]:
        result = await self.session.execute(select(BotSetting).order_by(BotSetting.key))
        return list(result.scalars().all())


class LogRepository:
    def __init__(self, session: AsyncSession):
        self.session = session

    async def log_download(self, app_id: int, user_telegram_id: int, version: Optional[str] = None, download_type: str = "TELEGRAM_FILE") -> None:
        log = DownloadLog(
            app_id=app_id,
            user_telegram_id=user_telegram_id,
            version_number=version,
            download_type=download_type
        )
        self.session.add(log)

    async def log_admin_activity(self, admin_telegram_id: int, action: str, details: Optional[str] = None) -> None:
        log = AdminActivityLog(
            admin_telegram_id=admin_telegram_id,
            action=action,
            details=details
        )
        self.session.add(log)

    async def count_total_downloads(self) -> int:
        result = await self.session.execute(select(func.count(DownloadLog.id)))
        return result.scalar_one() or 0

    async def get_recent_admin_activities(self, limit: int = 10) -> List[AdminActivityLog]:
        result = await self.session.execute(
            select(AdminActivityLog).order_by(desc(AdminActivityLog.created_at)).limit(limit)
        )
        return list(result.scalars().all())
