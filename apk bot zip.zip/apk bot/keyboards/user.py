from typing import List, Optional
from aiogram.types import (
    ReplyKeyboardMarkup,
    KeyboardButton,
    InlineKeyboardMarkup,
    InlineKeyboardButton,
)
from database.models import Category, App, Channel

def get_main_reply_keyboard(is_admin: bool = False) -> ReplyKeyboardMarkup:
    """Asosiy foydalanuvchi menyusi (Reply Keyboard)."""
    buttons = [
        [KeyboardButton(text="📱 Ilovalar katalogi"), KeyboardButton(text="🔎 Ilova qidirish")],
        [KeyboardButton(text="🗂 Kategoriyalar")],
        [KeyboardButton(text="🆕 Yangi ilovalar"), KeyboardButton(text="🔥 Mashhur ilovalar")],
        [KeyboardButton(text="📩 Adminga murojaat"), KeyboardButton(text="ℹ️ Bot haqida")],
    ]
    if is_admin:
        buttons.append([KeyboardButton(text="⚙️ Admin panel")])

    return ReplyKeyboardMarkup(
        keyboard=buttons,
        resize_keyboard=True,
        is_persistent=True,
        input_field_placeholder="Quyidagi bo'limlardan birini tanlang...",
    )

def get_categories_inline_keyboard(categories: List[Category]) -> InlineKeyboardMarkup:
    """Kategoriyalar ro'yxati inline tugmalari."""
    keyboard: List[List[InlineKeyboardButton]] = []
    row: List[InlineKeyboardButton] = []
    
    for idx, cat in enumerate(categories):
        btn = InlineKeyboardButton(
            text=f"{cat.icon} {cat.name}",
            callback_data=f"cat_{cat.id}_1"
        )
        row.append(btn)
        if len(row) == 2 or idx == len(categories) - 1:
            keyboard.append(row)
            row = []

    keyboard.append([InlineKeyboardButton(text="🔙 Bosh sahifa", callback_data="nav_home")])
    return InlineKeyboardMarkup(inline_keyboard=keyboard)

def get_apps_paginated_keyboard(
    apps: List[App],
    current_page: int,
    total_count: int,
    limit: int = 6,
    prefix: str = "applist",
    category_id: Optional[int] = None
) -> InlineKeyboardMarkup:
    """Ilovalar ro'yxatini sahifalab ko'rsatish."""
    total_pages = max(1, (total_count + limit - 1) // limit)
    keyboard: List[List[InlineKeyboardButton]] = []

    # Ilovalar tugmalari (2 tadan har qatorda)
    row: List[InlineKeyboardButton] = []
    for idx, app in enumerate(apps):
        row.append(
            InlineKeyboardButton(
                text=f"📦 {app.title}",
                callback_data=f"app_view_{app.id}"
            )
        )
        if len(row) == 2 or idx == len(apps) - 1:
            keyboard.append(row)
            row = []

    # Sahifalash tugmalari
    nav_row: List[InlineKeyboardButton] = []
    cat_param = f"_{category_id}" if category_id else ""

    if current_page > 1:
        nav_row.append(
            InlineKeyboardButton(
                text="◀️ Oldingi",
                callback_data=f"{prefix}{cat_param}_p_{current_page - 1}"
            )
        )
    
    nav_row.append(
        InlineKeyboardButton(
            text=f"📄 {current_page}/{total_pages}",
            callback_data="noop"
        )
    )

    if current_page < total_pages:
        nav_row.append(
            InlineKeyboardButton(
                text="Keyingi ▶️",
                callback_data=f"{prefix}{cat_param}_p_{current_page + 1}"
            )
        )

    if len(nav_row) > 1 or total_pages > 1:
        keyboard.append(nav_row)

    if category_id:
        keyboard.append([InlineKeyboardButton(text="🗂 Barcha kategoriyalar", callback_data="nav_categories")])
    else:
        keyboard.append([InlineKeyboardButton(text="🔙 Bosh sahifa", callback_data="nav_home")])

    return InlineKeyboardMarkup(inline_keyboard=keyboard)

def get_app_details_keyboard(app_id: int, has_file: bool = False, download_url: Optional[str] = None, back_callback: str = "applist_p_1") -> InlineKeyboardMarkup:
    """Ilova batafsil kartasi tugmalari."""
    keyboard: List[List[InlineKeyboardButton]] = []

    # Yuklab olish tugmasi
    if has_file:
        keyboard.append([
            InlineKeyboardButton(
                text="📥 Faylni yuklab olish (Telegram)",
                callback_data=f"app_dl_{app_id}"
            )
        ])
    elif download_url:
        keyboard.append([
            InlineKeyboardButton(
                text="🌐 Yuklab olish havolasi",
                url=download_url
            )
        ])

    keyboard.append([
        InlineKeyboardButton(text="🔙 Orqaga", callback_data=back_callback)
    ])
    return InlineKeyboardMarkup(inline_keyboard=keyboard)

def get_subscription_keyboard(channels: List[Channel]) -> InlineKeyboardMarkup:
    """Majburiy obuna kanallari tugmalari."""
    keyboard: List[List[InlineKeyboardButton]] = []
    
    for idx, ch in enumerate(channels, 1):
        url = ch.invite_link
        if not url and ch.username:
            url = f"https://t.me/{ch.username.lstrip('@')}"
        if not url:
            url = f"https://t.me/c/{abs(ch.channel_id)}"

        btn_text = f"📢 {idx}. {ch.title}"
        if ch.channel_type == "REQUEST":
            btn_text += " (So'rov yuborish)"
        keyboard.append([InlineKeyboardButton(text=btn_text, url=url)])

    keyboard.append([
        InlineKeyboardButton(text="✅ Obunani tekshirish", callback_data="check_subscription")
    ])
    return InlineKeyboardMarkup(inline_keyboard=keyboard)

def get_cancel_inline_keyboard() -> InlineKeyboardMarkup:
    """Bekor qilish tugmasi."""
    return InlineKeyboardMarkup(
        inline_keyboard=[[InlineKeyboardButton(text="❌ Bekor qilish", callback_data="cancel_action")]]
    )
