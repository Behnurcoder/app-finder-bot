from typing import List, Optional
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from database.models import Category, App, Admin, Channel, SupportTicket

def get_admin_main_keyboard(is_superadmin: bool = False) -> InlineKeyboardMarkup:
    """Admin panelning asosiy menyusi."""
    keyboard = [
        [
            InlineKeyboardButton(text="📊 Statistika", callback_data="adm_stats"),
            InlineKeyboardButton(text="➕ Ilova qo‘shish", callback_data="adm_add_app"),
        ],
        [
            InlineKeyboardButton(text="📱 Ilovalarni boshqarish", callback_data="adm_manage_apps_1"),
            InlineKeyboardButton(text="🗂 Kategoriyalarni boshqarish", callback_data="adm_manage_cats"),
        ],
        [
            InlineKeyboardButton(text="📢 Kanallarni boshqarish", callback_data="adm_manage_channels"),
            InlineKeyboardButton(text="✉️ Foydalanuvchi xabarlari", callback_data="adm_support_1"),
        ],
        [
            InlineKeyboardButton(text="📨 Bot orqali xabar yuborish", callback_data="adm_broadcast"),
            InlineKeyboardButton(text="⚙️ Bot sozlamalari", callback_data="adm_settings"),
        ],
    ]
    if is_superadmin:
        keyboard.append([
            InlineKeyboardButton(text="👮 Adminlarni boshqarish", callback_data="adm_manage_admins")
        ])

    keyboard.append([
        InlineKeyboardButton(text="🔙 Asosiy botga qaytish", callback_data="adm_back_to_user")
    ])
    return InlineKeyboardMarkup(inline_keyboard=keyboard)

def get_admin_apps_keyboard(apps: List[App], page: int, total_count: int, limit: int = 6) -> InlineKeyboardMarkup:
    """Adminlar uchun ilovalar ro'yxati."""
    total_pages = max(1, (total_count + limit - 1) // limit)
    keyboard: List[List[InlineKeyboardButton]] = []

    for app in apps:
        status_icon = "🟢" if app.is_active else "🔴"
        keyboard.append([
            InlineKeyboardButton(
                text=f"{status_icon} {app.title} ({app.platform})",
                callback_data=f"adm_app_{app.id}"
            )
        ])

    nav_row: List[InlineKeyboardButton] = []
    if page > 1:
        nav_row.append(InlineKeyboardButton(text="◀️ Oldingi", callback_data=f"adm_manage_apps_{page - 1}"))
    nav_row.append(InlineKeyboardButton(text=f"📄 {page}/{total_pages}", callback_data="noop"))
    if page < total_pages:
        nav_row.append(InlineKeyboardButton(text="Keyingi ▶️", callback_data=f"adm_manage_apps_{page + 1}"))

    if len(nav_row) > 1 or total_pages > 1:
        keyboard.append(nav_row)

    keyboard.append([
        InlineKeyboardButton(text="➕ Yangi ilova qo'shish", callback_data="adm_add_app"),
        InlineKeyboardButton(text="🔙 Admin menyu", callback_data="adm_home"),
    ])
    return InlineKeyboardMarkup(inline_keyboard=keyboard)

def get_admin_app_detail_keyboard(app: App) -> InlineKeyboardMarkup:
    """Admin uchun bitta ilovani boshqarish menyusi."""
    status_text = "🙈 Yashirish" if app.is_active else "👁 Faollashtirish"
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="✏️ Tahrirlash", callback_data=f"adm_edit_app_{app.id}"),
                InlineKeyboardButton(text="🆕 Yangi versiya qo'shish", callback_data=f"adm_new_ver_{app.id}"),
            ],
            [
                InlineKeyboardButton(text=status_text, callback_data=f"adm_toggle_app_{app.id}"),
                InlineKeyboardButton(text="🗑 O'chirish", callback_data=f"adm_del_app_confirm_{app.id}"),
            ],
            [
                InlineKeyboardButton(text="🔙 Ilovalar ro'yxatiga", callback_data="adm_manage_apps_1")
            ]
        ]
    )

def get_admin_delete_confirm_keyboard(target_type: str, target_id: int) -> InlineKeyboardMarkup:
    """O'chirishni tasdiqlash tugmalari."""
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="🗑 Ha, o'chirilsin", callback_data=f"adm_confirm_del_{target_type}_{target_id}"),
                InlineKeyboardButton(text="❌ Bekor qilish", callback_data=f"adm_cancel_del_{target_type}_{target_id}"),
            ]
        ]
    )

def get_admin_categories_keyboard(categories: List[Category]) -> InlineKeyboardMarkup:
    """Kategoriyalarni boshqarish tugmalari."""
    keyboard: List[List[InlineKeyboardButton]] = []
    for cat in categories:
        status_icon = "🟢" if cat.is_active else "🔴"
        keyboard.append([
            InlineKeyboardButton(
                text=f"{status_icon} {cat.icon} {cat.name}",
                callback_data=f"adm_cat_{cat.id}"
            )
        ])
    keyboard.append([
        InlineKeyboardButton(text="➕ Kategoriya qo'shish", callback_data="adm_add_cat"),
        InlineKeyboardButton(text="🔙 Admin menyu", callback_data="adm_home"),
    ])
    return InlineKeyboardMarkup(inline_keyboard=keyboard)

def get_admin_category_detail_keyboard(cat: Category) -> InlineKeyboardMarkup:
    """Bitta kategoriyani boshqarish tugmalari."""
    status_text = "🙈 Yashirish" if cat.is_active else "👁 Faollashtirish"
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text=status_text, callback_data=f"adm_toggle_cat_{cat.id}"),
                InlineKeyboardButton(text="🗑 O'chirish", callback_data=f"adm_del_cat_confirm_{cat.id}"),
            ],
            [
                InlineKeyboardButton(text="🔙 Kategoriyalar ro'yxatiga", callback_data="adm_manage_cats")
            ]
        ]
    )

def get_admin_channels_keyboard(channels: List[Channel]) -> InlineKeyboardMarkup:
    """Kanallarni boshqarish tugmalari."""
    keyboard: List[List[InlineKeyboardButton]] = []
    for ch in channels:
        status_icon = "🟢" if ch.is_active else "🔴"
        keyboard.append([
            InlineKeyboardButton(
                text=f"{status_icon} {ch.title} ({ch.channel_type})",
                callback_data=f"adm_ch_{ch.id}"
            )
        ])
    keyboard.append([
        InlineKeyboardButton(text="➕ Yangi kanal qo'shish", callback_data="adm_add_channel"),
        InlineKeyboardButton(text="🔙 Admin menyu", callback_data="adm_home"),
    ])
    return InlineKeyboardMarkup(inline_keyboard=keyboard)

def get_admin_channel_detail_keyboard(channel: Channel) -> InlineKeyboardMarkup:
    """Bitta kanalni boshqarish tugmalari."""
    status_text = "🔴 Nofaol qilish" if channel.is_active else "🟢 Faollashtirish"
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text=status_text, callback_data=f"adm_toggle_ch_{channel.id}"),
                InlineKeyboardButton(text="🗑 O'chirish", callback_data=f"adm_del_ch_confirm_{channel.id}"),
            ],
            [
                InlineKeyboardButton(text="🔙 Kanallar ro'yxatiga", callback_data="adm_manage_channels")
            ]
        ]
    )

def get_admin_manage_admins_keyboard(admins: List[Admin]) -> InlineKeyboardMarkup:
    """Adminlar ro'yxatini boshqarish (Superadmin uchun)."""
    keyboard: List[List[InlineKeyboardButton]] = []
    for adm in admins:
        status_icon = "🟢" if adm.is_active else "🔴"
        keyboard.append([
            InlineKeyboardButton(
                text=f"{status_icon} {adm.full_name} ({adm.role})",
                callback_data=f"adm_view_admin_{adm.telegram_id}"
            )
        ])
    keyboard.append([
        InlineKeyboardButton(text="➕ Yangi admin qo'shish", callback_data="adm_add_new_admin"),
        InlineKeyboardButton(text="🔙 Admin menyu", callback_data="adm_home"),
    ])
    return InlineKeyboardMarkup(inline_keyboard=keyboard)

def get_admin_single_manage_keyboard(admin: Admin) -> InlineKeyboardMarkup:
    """Bitta adminni boshqarish."""
    keyboard: List[List[InlineKeyboardButton]] = []
    if admin.role != "SUPERADMIN":
        status_text = "🔒 Bloklash" if admin.is_active else "🔓 Blokdan chiqarish"
        keyboard.append([
            InlineKeyboardButton(text=status_text, callback_data=f"adm_toggle_admin_{admin.telegram_id}"),
            InlineKeyboardButton(text="🗑 O'chirish", callback_data=f"adm_del_admin_confirm_{admin.telegram_id}"),
        ])
    keyboard.append([
        InlineKeyboardButton(text="🔙 Adminlar ro'yxatiga", callback_data="adm_manage_admins")
    ])
    return InlineKeyboardMarkup(inline_keyboard=keyboard)

def get_admin_support_tickets_keyboard(tickets: List[SupportTicket], page: int, total_count: int, limit: int = 8) -> InlineKeyboardMarkup:
    """Support ticketlar ro'yxati."""
    total_pages = max(1, (total_count + limit - 1) // limit)
    keyboard: List[List[InlineKeyboardButton]] = []

    for t in tickets:
        status_emojis = {
            "YANGI": "🔴",
            "KO'RIB_CHIQILMOQDA": "🟡",
            "JAVOB_BERILDI": "🟢",
            "YOPILDI": "⚪️"
        }
        emoji = status_emojis.get(t.status, "✉️")
        keyboard.append([
            InlineKeyboardButton(
                text=f"{emoji} {t.ticket_number} - {t.subject[:25]}",
                callback_data=f"adm_ticket_{t.id}"
            )
        ])

    nav_row: List[InlineKeyboardButton] = []
    if page > 1:
        nav_row.append(InlineKeyboardButton(text="◀️ Oldingi", callback_data=f"adm_support_{page - 1}"))
    nav_row.append(InlineKeyboardButton(text=f"📄 {page}/{total_pages}", callback_data="noop"))
    if page < total_pages:
        nav_row.append(InlineKeyboardButton(text="Keyingi ▶️", callback_data=f"adm_support_{page + 1}"))

    if len(nav_row) > 1 or total_pages > 1:
        keyboard.append(nav_row)

    keyboard.append([
        InlineKeyboardButton(text="🔙 Admin menyu", callback_data="adm_home")
    ])
    return InlineKeyboardMarkup(inline_keyboard=keyboard)

def get_admin_ticket_actions_keyboard(ticket_id: int, status: str) -> InlineKeyboardMarkup:
    """Bitta chipta bo'yicha amallar."""
    keyboard: List[List[InlineKeyboardButton]] = [
        [
            InlineKeyboardButton(text="✍️ Javob yozish", callback_data=f"adm_reply_ticket_{ticket_id}")
        ]
    ]
    if status != "YOPILDI":
        keyboard.append([
            InlineKeyboardButton(text="🔒 Chiptani yopish", callback_data=f"adm_close_ticket_{ticket_id}")
        ])
    keyboard.append([
        InlineKeyboardButton(text="🔙 Murojaatlar ro'yxatiga", callback_data="adm_support_1")
    ])
    return InlineKeyboardMarkup(inline_keyboard=keyboard)

def get_save_cancel_keyboard(callback_prefix: str = "app") -> InlineKeyboardMarkup:
    """Saqlash, tahrirlash va bekor qilish."""
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="✅ Saqlash", callback_data=f"{callback_prefix}_save"),
                InlineKeyboardButton(text="✏️ Qayta kiritish", callback_data=f"{callback_prefix}_retry"),
            ],
            [
                InlineKeyboardButton(text="❌ Bekor qilish", callback_data=f"{callback_prefix}_cancel")
            ]
        ]
    )

def get_broadcast_confirm_keyboard() -> InlineKeyboardMarkup:
    """Xabar yuborishni tasdiqlash."""
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="🚀 Yuborishni boshlash", callback_data="bc_confirm_send"),
                InlineKeyboardButton(text="❌ Bekor qilish", callback_data="bc_cancel"),
            ]
        ]
    )

def get_admin_settings_keyboard(sub_enabled: bool, maint_enabled: bool) -> InlineKeyboardMarkup:
    """Bot sozlamalari menyusi."""
    sub_text = "🟢 Majburiy obuna: YOQILGAN" if sub_enabled else "🔴 Majburiy obuna: O'CHIRILGAN"
    maint_text = "🔴 Texnik tanaffus: YOQILGAN" if maint_enabled else "🟢 Texnik tanaffus: O'CHIRILGAN"
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text=sub_text, callback_data="adm_toggle_setting_sub")],
            [InlineKeyboardButton(text=maint_text, callback_data="adm_toggle_setting_maint")],
            [InlineKeyboardButton(text="🔙 Admin menyu", callback_data="adm_home")],
        ]
    )
