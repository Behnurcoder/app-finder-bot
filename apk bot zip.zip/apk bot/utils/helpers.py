import re
import html
from datetime import datetime

UZ_TRANSLIT = {
    'а': 'a', 'б': 'b', 'в': 'v', 'г': 'g', 'д': 'd', 'е': 'e', 'ё': 'yo',
    'ж': 'j', 'з': 'z', 'и': 'i', 'й': 'y', 'к': 'k', 'л': 'l', 'м': 'm',
    'н': 'n', 'о': 'o', 'п': 'p', 'р': 'r', 'с': 's', 'т': 't', 'у': 'u',
    'ф': 'f', 'х': 'x', 'ц': 'ts', 'ч': 'ch', 'ш': 'sh', 'щ': 'sh', 'ъ': '',
    'ы': 'i', 'ь': '', 'э': 'e', 'ю': 'yu', 'я': 'ya', 'ў': 'o', 'ғ': 'g',
    'ҳ': 'h', 'қ': 'q',
}

def slugify(text: str) -> str:
    """Matnni lotincha URL/slug ko'rinishiga keltiradi."""
    text = text.lower().strip()
    for cyr, lat in UZ_TRANSLIT.items():
        text = text.replace(cyr, lat)
    text = re.sub(r'[^a-z0-9\s-]', '', text)
    text = re.sub(r'[\s-]+', '-', text)
    return text.strip('-') or 'app'

def format_file_size(size_bytes: int) -> str:
    """Baytlarni KB, MB, GB formatida ko'rsatish."""
    if not size_bytes or size_bytes <= 0:
        return "Noma'lum"
    for unit in ['B', 'KB', 'MB', 'GB']:
        if size_bytes < 1024.0:
            return f"{size_bytes:.1f} {unit}"
        size_bytes /= 1024.0
    return f"{size_bytes:.1f} TB"

def format_datetime(dt: datetime) -> str:
    """Sanani o'zbekcha chiroyli formatda ko'rsatish."""
    if not dt:
        return "Noma'lum"
    return dt.strftime("%d.%m.%Y %H:%M")

def safe_html(text: str) -> str:
    """HTML teglar uchun matnni xavfsiz qochirish."""
    if not text:
        return ""
    return html.escape(text)
