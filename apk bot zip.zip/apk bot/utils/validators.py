import re
from typing import Optional, Tuple

ALLOWED_EXTENSIONS = {".apk", ".xapk", ".apks", ".zip", ".rar", ".ipa", ".exe", ".msi", ".dmg"}
MAX_FILE_SIZE_BYTES = 2000 * 1024 * 1024  # 2 GB (Telegram Bot API limit)

def validate_app_title(title: str) -> Tuple[bool, Optional[str]]:
    title = title.strip()
    if len(title) < 2:
        return False, "Ilova nomi kamida 2 ta belgidan iborat bo'lishi kerak."
    if len(title) > 100:
        return False, "Ilova nomi 100 ta belgidan oshmasligi kerak."
    return True, None

def validate_version_number(version: str) -> Tuple[bool, Optional[str]]:
    version = version.strip()
    if not version or len(version) > 50:
        return False, "Versiya raqami noto'g'ri (1-50 belgi oralig'ida bo'lishi kerak)."
    return True, None

def validate_file_name(file_name: str) -> Tuple[bool, Optional[str]]:
    if not file_name:
        return True, None
    ext = "." + file_name.split(".")[-1].lower() if "." in file_name else ""
    if ext and ext not in ALLOWED_EXTENSIONS:
        return False, f"Fayl kengaytmasi ruxsat etilmagan ({ext}). Ruxsat etilganlar: {', '.join(sorted(ALLOWED_EXTENSIONS))}"
    return True, None

def validate_url(url: str) -> bool:
    regex = re.compile(
        r'^(?:http|ftp)s?://' # http:// or https://
        r'(?:(?:[A-Z0-9](?:[A-Z0-9-]{0,61}[A-Z0-9])?\.)+(?:[A-Z]{2,6}\.?|[A-Z0-9-]{2,}\.?)|' # domain...
        r'localhost|' # localhost...
        r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})' # ...or ip
        r'(?::\d+)?' # optional port
        r'(?:/?|[/?]\S+)$', re.IGNORECASE)
    return re.match(regex, url) is not None
