import logging
from aiogram import Router, F
from aiogram.types import Message, CallbackQuery
from sqlalchemy.ext.asyncio import AsyncSession

from database.repositories import CategoryRepository
from services.app_service import AppService
from keyboards.user import (
    get_categories_inline_keyboard,
    get_apps_paginated_keyboard,
)

logger = logging.getLogger(__name__)

router = Router(name="categories_router")

PAGE_LIMIT = 6

@router.message(F.text == "🗂 Kategoriyalar")
async def show_categories(message: Message, session: AsyncSession):
    """Barcha faol kategoriyalar ro'yxatini ko'rsatish."""
    cat_repo = CategoryRepository(session)
    categories = await cat_repo.get_all_active()

    if not categories:
        await message.answer("ℹ️ Hozircha kategoriyalar mavjud emas.")
        return

    text = "🗂 <b>Ilovalar kategoriyalari:</b>\n\nO'zingizga qiziq bo'lgan kategoriyani tanlang:"
    await message.answer(
        text,
        parse_mode="HTML",
        reply_markup=get_categories_inline_keyboard(categories)
    )

@router.callback_query(F.data == "nav_categories")
async def callback_nav_categories(callback: CallbackQuery, session: AsyncSession):
    """Inline orqali kategoriyalarga qaytish."""
    cat_repo = CategoryRepository(session)
    categories = await cat_repo.get_all_active()

    text = "🗂 <b>Ilovalar kategoriyalari:</b>\n\nO'zingizga qiziq bo'lgan kategoriyani tanlang:"
    try:
        await callback.message.delete()
    except Exception:
        pass
    await callback.message.answer(
        text,
        parse_mode="HTML",
        reply_markup=get_categories_inline_keyboard(categories)
    )
    await callback.answer()

@router.callback_query(F.data.startswith("cat_"))
async def show_category_apps(callback: CallbackQuery, session: AsyncSession):
    """Tanlangan kategoriya bo'yicha ilovalarni ko'rsatish."""
    parts = callback.data.split("_")
    cat_id = int(parts[1])
    page = int(parts[2]) if len(parts) > 2 else 1

    cat_repo = CategoryRepository(session)
    category = await cat_repo.get_by_id(cat_id)
    if not category:
        await callback.answer("Kategoriya topilmadi.", show_alert=True)
        return

    app_service = AppService(session)
    apps, total = await app_service.list_apps(page=page, limit=PAGE_LIMIT, category_id=cat_id, only_active=True)

    if not apps:
        await callback.answer(f"«{category.name}» kategoriyasida hozircha ilovalar yo'q.", show_alert=True)
        return

    text = f"🗂 <b>{category.icon} {category.name}</b> (Jami: {total} ta)\n\nKerakli ilovani tanlang:"
    try:
        await callback.message.delete()
    except Exception:
        pass
    await callback.message.answer(
        text,
        parse_mode="HTML",
        reply_markup=get_apps_paginated_keyboard(
            apps,
            current_page=page,
            total_count=total,
            limit=PAGE_LIMIT,
            prefix="applist",
            category_id=cat_id
        )
    )
    await callback.answer()

@router.callback_query(F.data.startswith("applist_") and F.data.contains("_p_"))
async def paginate_category_apps(callback: CallbackQuery, session: AsyncSession):
    """Kategoriya ichida sahifalash."""
    # Format: applist_{cat_id}_p_{page} yoki applist_p_{page}
    data = callback.data
    parts = data.split("_p_")
    page = int(parts[1])
    prefix_parts = parts[0].split("_")

    cat_id = int(prefix_parts[1]) if len(prefix_parts) > 1 and prefix_parts[1].isdigit() else None

    app_service = AppService(session)
    apps, total = await app_service.list_apps(page=page, limit=PAGE_LIMIT, category_id=cat_id, only_active=True)

    cat_repo = CategoryRepository(session)
    cat_title = "Ilovalar katalogi"
    if cat_id:
        c = await cat_repo.get_by_id(cat_id)
        if c:
            cat_title = f"{c.icon} {c.name}"

    text = f"📱 <b>{cat_title}</b> (Jami: {total} ta)\n\nKerakli ilovani tanlang:"
    await callback.message.edit_text(
        text,
        parse_mode="HTML",
        reply_markup=get_apps_paginated_keyboard(
            apps,
            current_page=page,
            total_count=total,
            limit=PAGE_LIMIT,
            prefix="applist",
            category_id=cat_id
        )
    )
    await callback.answer()
