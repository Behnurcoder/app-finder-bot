import logging
from aiogram import Router, F, Bot
from aiogram.types import Message, CallbackQuery
from sqlalchemy.ext.asyncio import AsyncSession

from services.app_service import AppService
from keyboards.user import (
    get_apps_paginated_keyboard,
    get_app_details_keyboard,
)
from utils.helpers import safe_html, format_datetime

logger = logging.getLogger(__name__)

router = Router(name="apps_router")

PAGE_LIMIT = 6

def format_app_card(app) -> str:
    """Ilova haqida batafsil ma'lumot kartasi matni."""
    latest_ver = app.versions[0] if app.versions else None
    version_str = latest_ver.version_number if latest_ver else "1.0"
    file_size_str = latest_ver.file_size if (latest_ver and latest_ver.file_size) else "Noma'lum"
    cat_name = app.category.name if app.category else "Umumiy"
    cat_icon = app.category.icon if app.category else "📁"
    updated_str = format_datetime(app.updated_at)

    card = (
        f"📱 <b>{safe_html(app.title)}</b>\n\n"
        f"{cat_icon} <b>Kategoriya:</b> {safe_html(cat_name)}\n"
        f"🔢 <b>Joriy versiya:</b> <code>{safe_html(version_str)}</code>\n"
        f"💾 <b>Fayl hajmi:</b> {safe_html(file_size_str)}\n"
        f"💻 <b>Platforma:</b> {safe_html(app.platform)}\n"
        f"📥 <b>Yuklab olishlar:</b> {app.downloads_count} marta\n"
        f"🕒 <b>Yangilangan sana:</b> {updated_str}\n\n"
        f"📝 <b>Ilova haqida ma'lumot:</b>\n"
        f"{safe_html(app.description)}\n\n"
        f"<i>Xavfsiz va tekshirilgan manba orqali yuklab oling.</i>"
    )
    return card

@router.message(F.text == "📱 Ilovalar katalogi")
async def show_app_catalog(message: Message, session: AsyncSession):
    """Barcha ilovalar katalogining 1-sahifasi."""
    app_service = AppService(session)
    apps, total = await app_service.list_apps(page=1, limit=PAGE_LIMIT, only_active=True)

    if not apps:
        await message.answer("ℹ️ Hozircha katalogda ilovalar mavjud emas. Tez orada yangi ilovalar qo'shiladi!")
        return

    text = f"📱 <b>Ilovalar katalogi</b> (Jami: {total} ta)\n\nKerakli ilovani tanlang:"
    await message.answer(
        text,
        parse_mode="HTML",
        reply_markup=get_apps_paginated_keyboard(apps, current_page=1, total_count=total, limit=PAGE_LIMIT, prefix="applist")
    )

@router.message(F.text == "🆕 Yangi ilovalar")
async def show_latest_apps(message: Message, session: AsyncSession):
    """So'nggi qo'shilgan yangi ilovalar."""
    app_service = AppService(session)
    apps = await app_service.get_latest_apps(limit=PAGE_LIMIT)

    if not apps:
        await message.answer("ℹ️ Hozircha yangi ilovalar mavjud emas.")
        return

    text = "🆕 <b>Yangi qo'shilgan ilovalar:</b>\n\nKerakli ilovani tanlang:"
    await message.answer(
        text,
        parse_mode="HTML",
        reply_markup=get_apps_paginated_keyboard(apps, current_page=1, total_count=len(apps), limit=PAGE_LIMIT, prefix="applist")
    )

@router.message(F.text == "🔥 Mashhur ilovalar")
async def show_popular_apps(message: Message, session: AsyncSession):
    """Eng ko'p yuklab olingan mashhur ilovalar."""
    app_service = AppService(session)
    apps = await app_service.get_popular_apps(limit=PAGE_LIMIT)

    if not apps:
        await message.answer("ℹ️ Hozircha mashhur ilovalar mavjud emas.")
        return

    text = "🔥 <b>Eng ko'p yuklab olingan mashhur ilovalar:</b>\n\nKerakli ilovani tanlang:"
    await message.answer(
        text,
        parse_mode="HTML",
        reply_markup=get_apps_paginated_keyboard(apps, current_page=1, total_count=len(apps), limit=PAGE_LIMIT, prefix="applist")
    )

@router.callback_query(F.data.startswith("applist_p_"))
async def paginate_general_apps(callback: CallbackQuery, session: AsyncSession):
    """Umumiy katalog paginatsiyasi."""
    page = int(callback.data.split("_p_")[1])
    app_service = AppService(session)
    apps, total = await app_service.list_apps(page=page, limit=PAGE_LIMIT, only_active=True)

    text = f"📱 <b>Ilovalar katalogi</b> (Jami: {total} ta)\n\nKerakli ilovani tanlang:"
    await callback.message.edit_text(
        text,
        parse_mode="HTML",
        reply_markup=get_apps_paginated_keyboard(apps, current_page=page, total_count=total, limit=PAGE_LIMIT, prefix="applist")
    )
    await callback.answer()

@router.callback_query(F.data.startswith("app_view_"))
async def view_app_details(callback: CallbackQuery, session: AsyncSession):
    """Bitta ilovani to'liq ma'lumotlari bilan ko'rish."""
    app_id = int(callback.data.split("app_view_")[1])
    app_service = AppService(session)
    app = await app_service.get_app_details(app_id)

    if not app:
        await callback.answer("Kechirasiz, ilova topilmadi yoki o'chirilgan.", show_alert=True)
        return

    latest_ver = app.versions[0] if app.versions else None
    has_file = bool(latest_ver and latest_ver.file_id)
    download_url = latest_ver.download_url if latest_ver else None

    card_text = format_app_card(app)
    kb = get_app_details_keyboard(app_id, has_file=has_file, download_url=download_url)

    try:
        await callback.message.delete()
    except Exception:
        pass

    if app.photo_file_id:
        try:
            await callback.message.answer_photo(
                photo=app.photo_file_id,
                caption=card_text,
                parse_mode="HTML",
                reply_markup=kb
            )
            await callback.answer()
            return
        except Exception as e:
            logger.warning(f"Rasm yuklashda xatolik ({e}), matn ko'rinishida yuboriladi.")

    await callback.message.answer(
        card_text,
        parse_mode="HTML",
        reply_markup=kb
    )
    await callback.answer()

@router.callback_query(F.data.startswith("app_dl_"))
async def download_app_file(callback: CallbackQuery, bot: Bot, session: AsyncSession):
    """Ilova faylini Telegram orqali yuborish."""
    app_id = int(callback.data.split("app_dl_")[1])
    app_service = AppService(session)
    app = await app_service.get_app_details(app_id)

    if not app:
        await callback.answer("Ilova topilmadi.", show_alert=True)
        return

    latest_ver = app.versions[0] if app.versions else None
    if not latest_ver or not latest_ver.file_id:
        await callback.answer("Ushbu ilova uchun fayl yuklanmagan.", show_alert=True)
        return

    await callback.answer("Fayl yuborilmoqda, kuting...")
    
    caption = (
        f"📦 <b>{safe_html(app.title)}</b>\n"
        f"🔢 Versiya: <code>{safe_html(latest_ver.version_number)}</code>\n"
        f"💾 Hajmi: {safe_html(latest_ver.file_size or 'Noma\'lum')}\n\n"
        f"<i>@AppFinderBot orqali yuklab olindi.</i>"
    )

    try:
        await bot.send_document(
            chat_id=callback.from_user.id,
            document=latest_ver.file_id,
            caption=caption,
            parse_mode="HTML"
        )
        # Yuklab olish statistikasini yangilash
        await app_service.register_download(
            app_id=app.id,
            user_telegram_id=callback.from_user.id,
            version=latest_ver.version_number,
            download_type="TELEGRAM_FILE"
        )
    except Exception as e:
        logger.error(f"Faylni yuborishda xatolik: {e}")
        await callback.message.answer("⚠️ Faylni yuborishda xatolik yuz berdi. Iltimos, keyinroq qayta urinib ko'ring.")
