import logging
from aiogram import Router, F, Bot
from aiogram.types import Message
from aiogram.fsm.context import FSMContext
from sqlalchemy.ext.asyncio import AsyncSession

from states.user_states import SupportStates
from services.support_service import SupportService
from keyboards.user import get_cancel_inline_keyboard, get_main_reply_keyboard
from database.repositories import AdminRepository
from utils.helpers import safe_html

logger = logging.getLogger(__name__)

router = Router(name="support_router")

@router.message(F.text == "📩 Adminga murojaat")
async def start_support_ticket(message: Message, state: FSMContext):
    """Murojaat yaratish jarayonini boshlash."""
    await state.set_state(SupportStates.waiting_for_subject)
    text = (
        "📩 <b>Adminga murojaat yo'llash:</b>\n\n"
        "Iltimos, avval murojaatingiz mavzusini qisqacha yozib yuboring:\n"
        "<i>(Masalan: Yangi ilova so'rovi, Xatolik haqida, Taklif)</i>"
    )
    await message.answer(
        text,
        parse_mode="HTML",
        reply_markup=get_cancel_inline_keyboard()
    )

@router.message(SupportStates.waiting_for_subject)
async def process_support_subject(message: Message, state: FSMContext):
    """Murojaat mavzusini qabul qilish."""
    subject = message.text.strip()
    if len(subject) < 3:
        await message.answer("⚠️ Mavzu kamida 3 ta belgidan iborat bo'lishi kerak. Qaytadan kiriting:")
        return

    await state.update_data(subject=subject)
    await state.set_state(SupportStates.waiting_for_message)

    await message.answer(
        f"📌 Mavzu: <b>{safe_html(subject)}</b>\n\n"
        f"Endi murojaatingiz mazmunini to'liq va tushunarli qilib yozib yuboring:",
        parse_mode="HTML",
        reply_markup=get_cancel_inline_keyboard()
    )

@router.message(SupportStates.waiting_for_message)
async def process_support_message(message: Message, bot: Bot, state: FSMContext, session: AsyncSession):
    """Murojaat matnini qabul qilish va saqlash."""
    message_text = message.text.strip() if message.text else ""
    if len(message_text) < 5:
        await message.answer("⚠️ Xabar matni kamida 5 ta belgidan iborat bo'lishi kerak. Qaytadan kiriting:")
        return

    data = await state.get_data()
    subject = data.get("subject", "Umumiy murojaat")

    support_service = SupportService(session)
    user_name = message.from_user.full_name or "Foydalanuvchi"
    ticket = await support_service.submit_ticket(
        bot=bot,
        user_id=message.from_user.id,
        user_name=user_name,
        subject=subject,
        message_text=message_text
    )

    await state.clear()
    admin_repo = AdminRepository(session)
    is_admin = await admin_repo.is_admin(message.from_user.id)

    success_text = (
        f"✅ <b>Murojaatingiz muvaffaqiyatli qabul qilindi!</b>\n\n"
        f"🎫 <b>Chipta raqami:</b> <code>{ticket.ticket_number}</code>\n"
        f"📌 <b>Mavzu:</b> {safe_html(subject)}\n\n"
        f"Administratorlarimiz murojaatingizni ko'rib chiqib, tez orada bot orqali javob yozishadi. "
        f"Murojaat uchun rahmat!"
    )
    await message.answer(
        success_text,
        parse_mode="HTML",
        reply_markup=get_main_reply_keyboard(is_admin=is_admin)
    )
