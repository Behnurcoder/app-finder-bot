import logging
from aiogram import Router, F, Bot
from aiogram.filters import CommandStart, Command
from aiogram.types import Message, CallbackQuery
from aiogram.fsm.context import FSMContext
from sqlalchemy.ext.asyncio import AsyncSession

from database.repositories import AdminRepository, SettingRepository
from keyboards.user import (
    get_main_reply_keyboard,
    get_subscription_keyboard,
)
from services.channel_service import ChannelService
from utils.helpers import safe_html

logger = logging.getLogger(__name__)

router = Router(name="start_router")

@router.message(CommandStart())
async def cmd_start(message: Message, bot: Bot, session: AsyncSession, state: FSMContext):
    """Start buyrug'i va majburiy obuna tekshiruvi."""
    await state.clear()
    user_id = message.from_user.id
    admin_repo = AdminRepository(session)
    channel_service = ChannelService(session)
    setting_repo = SettingRepository(session)

    is_admin = await admin_repo.is_admin(user_id)

    # Majburiy obunani tekshirish
    is_subscribed, missing_channels = await channel_service.check_user_subscription(bot, user_id)
    if not is_subscribed:
        sub_text = (
            "👋 **Assalomu alaykum!**\n\n"
            "Botdan to'liq foydalanish uchun quyidagi rasmiy kanallarimizga obuna bo'ling va "
            "**«✅ Obunani tekshirish»** tugmasini bosing:"
        )
        await message.answer(
            sub_text,
            parse_mode="Markdown",
            reply_markup=get_subscription_keyboard(missing_channels)
        )
        return

    welcome_text = (
        f"👋 **Assalomu alaykum, {safe_html(message.from_user.first_name)}!**\n\n"
        f"📱 **App Finder** — Telegram ilovalar katalogiga xush kelibsiz!\n\n"
        f"Ushbu bot yordamida siz eng sara dasturlarni qidirishingiz, "
        f"kategoriyalar bo'yicha ko'rishingiz va yuklab olishingiz mumkin.\n\n"
        f"Kerakli bo'limni tanlash uchun pastdagi menyudan foydalaning 👇"
    )
    await message.answer(
        welcome_text,
        parse_mode="HTML",
        reply_markup=get_main_reply_keyboard(is_admin=is_admin)
    )

@router.message(F.text == "ℹ️ Bot haqida")
async def show_about(message: Message, session: AsyncSession):
    """Bot haqida ma'lumot ko'rsatish."""
    setting_repo = SettingRepository(session)
    about_text = await setting_repo.get(
        "about_text",
        "📱 **App Finder Bot** — foydali dasturlar va ilovalar katalogi."
    )
    await message.answer(about_text, parse_mode="Markdown")

@router.callback_query(F.data == "nav_home")
async def callback_nav_home(callback: CallbackQuery, session: AsyncSession, state: FSMContext):
    """Inline tugmalardan bosh sahifaga qaytish."""
    await state.clear()
    admin_repo = AdminRepository(session)
    is_admin = await admin_repo.is_admin(callback.from_user.id)

    welcome_text = (
        f"👋 **Asosiy menyudasiz!**\n\n"
        f"Quyidagi bo'limlardan birini tanlang yoki ilova nomini qidiruvga yuboring:"
    )
    try:
        await callback.message.delete()
    except Exception:
        pass

    await callback.message.answer(
        welcome_text,
        parse_mode="Markdown",
        reply_markup=get_main_reply_keyboard(is_admin=is_admin)
    )
    await callback.answer()

@router.callback_query(F.data == "cancel_action")
async def callback_cancel_action(callback: CallbackQuery, state: FSMContext, session: AsyncSession):
    """FSM holatini bekor qilish."""
    await state.clear()
    admin_repo = AdminRepository(session)
    is_admin = await admin_repo.is_admin(callback.from_user.id)
    try:
        await callback.message.delete()
    except Exception:
        pass
    await callback.message.answer(
        "Amal bekor qilindi.",
        reply_markup=get_main_reply_keyboard(is_admin=is_admin)
    )
    await callback.answer("Bekor qilindi")

@router.callback_query(F.data == "noop")
async def callback_noop(callback: CallbackQuery):
    await callback.answer()
