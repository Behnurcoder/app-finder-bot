from aiogram import Router

from handlers.start import router as start_router
from handlers.subscriptions import router as subscriptions_router
from handlers.apps import router as apps_router
from handlers.categories import router as categories_router
from handlers.search import router as search_router
from handlers.support import router as support_router
from handlers.admin import router as admin_router

main_router = Router(name="main_router")

# Routerlarni to'g'ri tartibda ulash
main_router.include_router(admin_router)
main_router.include_router(subscriptions_router)
main_router.include_router(apps_router)
main_router.include_router(categories_router)
main_router.include_router(search_router)
main_router.include_router(support_router)
main_router.include_router(start_router)

__all__ = ["main_router"]
