import logging
from aiogram import Router, F
from aiogram.types import Message, CallbackQuery
from aiogram.fsm.context import FSMContext
from sqlalchemy.ext.asyncio import AsyncSession

from services.app_service import AppService
from states.user_states import SearchStates
from keyboards.user import get_cancel_inline_keyboard, get_apps_paginated_keyboard, get_main_reply_keyboard
from database.repositories import AdminRepository
from utils.helpers import safe_html

logger = logging.getLogger(__name__)

router = Router(name="search_router")

PAGE_LIMIT = 6

@router.message(F.text == "🔎 Ilova qidirish")
async def start_search(message: Message, state: FSMContext):
    """Qidiruv rejimini ishga tushirish."""
    await state.set_state(SearchStates.waiting_for_query)
    text = (
        "🔎 <b>Ilova qidirish:</b>\n\n"
        "Qidirmoqchi bo'lgan ilova nomini yoki uning bir qismini yozib yuboring.\n"
        "<i>(Katta-kichik harflar farqlanmaydi)</i>"
    )
    await message.answer(
        text,
        parse_mode="HTML",
        reply_markup=get_cancel_inline_keyboard()
    )

@router.message(SearchStates.waiting_for_query)
async def process_search_query(message: Message, state: FSMContext, session: AsyncSession):
    """Qidiruv so'rovini qabul qilish va natijalarni chiqarish."""
    query_text = message.text.strip()
    if len(query_text) < 2:
        await message.answer("⚠️ Qidiruv so'rovi kamida 2 ta belgidan iborat bo'lishi kerak. Qaytadan yozing:")
        return

    app_service = AppService(session)
    apps, total = await app_service.search_apps(query=query_text, page=1, limit=PAGE_LIMIT, only_active=True)

    await state.clear()

    if not apps:
        admin_repo = AdminRepository(session)
        is_admin = await admin_repo.is_admin(message.from_user.id)
        not_found_text = (
            f"❌ Kechirasiz, <b>«{safe_html(query_text)}»</b> bo'yicha hech qanday ilova topilmadi.\n\n"
            f"Iltimos, ilova nomini to'g'ri yozganingizga ishonch hosil qiling yoki boshqa kalit so'z bilan qidirib ko'ring."
        )
        await message.answer(
            not_found_text,
            parse_mode="HTML",
            reply_markup=get_main_reply_keyboard(is_admin=is_admin)
        )
        return

    text = f"🔎 <b>«{safe_html(query_text)}»</b> bo'yicha topilgan natijalar ({total} ta):\n\nKerakli ilovani tanlang:"
    await message.answer(
        text,
        parse_mode="HTML",
        reply_markup=get_apps_paginated_keyboard(
            apps,
            current_page=1,
            total_count=total,
            limit=PAGE_LIMIT,
            prefix="applist"
        )
    )
