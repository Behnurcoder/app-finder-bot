import logging
from typing import Optional
from aiogram import Router, F, Bot
from aiogram.filters import Command
from aiogram.types import Message, CallbackQuery, Document, PhotoSize, InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.fsm.context import FSMContext
from sqlalchemy.ext.asyncio import AsyncSession

from config import config
from database.repositories import (
    AdminRepository,
    CategoryRepository,
    AppRepository,
    ChannelRepository,
    SupportRepository,
    SettingRepository,
    LogRepository,
)
from database.models import App
from services.app_service import AppService
from services.statistics_service import StatisticsService
from services.support_service import SupportService
from services.broadcast_service import BroadcastService
from states.admin_states import (
    AddAppStates,
    AddVersionStates,
    ManageAdminStates,
    ManageChannelStates,
    ManageCategoryStates,
    BroadcastStates,
    SupportReplyStates,
)
from keyboards.admin import (
    get_admin_main_keyboard,
    get_admin_apps_keyboard,
    get_admin_app_detail_keyboard,
    get_admin_delete_confirm_keyboard,
    get_admin_categories_keyboard,
    get_admin_category_detail_keyboard,
    get_admin_channels_keyboard,
    get_admin_channel_detail_keyboard,
    get_admin_manage_admins_keyboard,
    get_admin_single_manage_keyboard,
    get_admin_support_tickets_keyboard,
    get_admin_ticket_actions_keyboard,
    get_save_cancel_keyboard,
    get_broadcast_confirm_keyboard,
    get_admin_settings_keyboard,
)
from keyboards.user import get_main_reply_keyboard
from utils.helpers import safe_html, format_file_size, format_datetime, slugify
from utils.validators import validate_app_title, validate_version_number, validate_file_name, validate_url

logger = logging.getLogger(__name__)

router = Router(name="admin_router")

PAGE_LIMIT = 6

async def check_admin_access(telegram_id: int, session: AsyncSession) -> tuple[bool, bool]:
    """Adminlik va superadminlikni tekshirish."""
    admin_repo = AdminRepository(session)
    is_super = (telegram_id == config.SUPERADMIN_ID) or await admin_repo.is_superadmin(telegram_id)
    is_adm = is_super or await admin_repo.is_admin(telegram_id)
    return is_adm, is_super

# ===================================================================
# 1. ASOSIY ADMIN MENYUSI
# ===================================================================

@router.message(Command("admin"))
@router.message(F.text == "⚙️ Admin panel")
async def show_admin_panel(message: Message, session: AsyncSession, state: FSMContext):
    """Admin panelga kirish."""
    await state.clear()
    is_adm, is_super = await check_admin_access(message.from_user.id, session)
    if not is_adm:
        await message.answer("⛔️ Kechirasiz, sizda admin panelga kirish huquqi yo'q!")
        return

    text = (
        f"👑 <b>App Finder — Administratorlar paneli</b>\n\n"
        f"Xush kelibsiz, <b>{safe_html(message.from_user.first_name)}</b>!\n"
        f"Sizning maqomingiz: <b>{'SUPERADMIN' if is_super else 'ADMIN'}</b>\n\n"
        f"Kerakli boshqaruv bo'limini tanlang:"
    )
    await message.answer(
        text,
        parse_mode="HTML",
        reply_markup=get_admin_main_keyboard(is_superadmin=is_super)
    )

@router.callback_query(F.data == "adm_home")
async def callback_adm_home(callback: CallbackQuery, session: AsyncSession, state: FSMContext):
    """Admin bosh menyusiga qaytish."""
    await state.clear()
    is_adm, is_super = await check_admin_access(callback.from_user.id, session)
    if not is_adm:
        await callback.answer("Ruxsat yo'q!", show_alert=True)
        return

    text = (
        f"👑 <b>Administratorlar paneli</b>\n\n"
        f"Kerakli bo'limni tanlang:"
    )
    try:
        await callback.message.edit_text(
            text,
            parse_mode="HTML",
            reply_markup=get_admin_main_keyboard(is_superadmin=is_super)
        )
    except Exception:
        await callback.message.answer(
            text,
            parse_mode="HTML",
            reply_markup=get_admin_main_keyboard(is_superadmin=is_super)
        )
    await callback.answer()

@router.callback_query(F.data == "adm_back_to_user")
async def callback_back_to_user(callback: CallbackQuery, session: AsyncSession):
    """Asosiy foydalanuvchi menyusiga qaytish."""
    try:
        await callback.message.delete()
    except Exception:
        pass
    is_adm, _ = await check_admin_access(callback.from_user.id, session)
    await callback.message.answer(
        "👋 Foydalanuvchi menyusiga qaytdingiz.",
        reply_markup=get_main_reply_keyboard(is_admin=is_adm)
    )
    await callback.answer()

# ===================================================================
# 2. STATISTIKA
# ===================================================================

@router.callback_query(F.data == "adm_stats")
async def show_stats(callback: CallbackQuery, session: AsyncSession):
    """Batafsil statistika ko'rsatish."""
    is_adm, is_super = await check_admin_access(callback.from_user.id, session)
    if not is_adm:
        await callback.answer("Ruxsat berilmagan!", show_alert=True)
        return

    stat_service = StatisticsService(session)
    stats = await stat_service.get_dashboard_stats()

    top_apps_str = ""
    if stats["top_apps"]:
        for idx, a in enumerate(stats["top_apps"], 1):
            top_apps_str += f"  {idx}. <b>{safe_html(a.title)}</b> — {a.downloads_count} marta\n"
    else:
        top_apps_str = "  <i>Hozircha yuklab olishlar yo'q</i>\n"

    text = (
        f"📊 <b>Botning to'liq statistikasi:</b>\n\n"
        f"👥 <b>Foydalanuvchilar:</b>\n"
        f"• Jami: <b>{stats['total_users']}</b> ta\n"
        f"• Bugungi yangi: <b>{stats['today_users']}</b> ta\n"
        f"• Faol (bloklamagan): <b>{stats['active_users']}</b> ta\n\n"
        f"📱 <b>Ilovalar:</b>\n"
        f"• Jami ilovalar: <b>{stats['total_apps']}</b> ta\n"
        f"• Faol katalogda: <b>{stats['active_apps']}</b> ta\n"
        f"• Jami yuklab olishlar: <b>{stats['total_downloads']}</b> marta\n\n"
        f"🔥 <b>Eng mashhur ilovalar:</b>\n"
        f"{top_apps_str}\n"
        f"✉️ <b>Murojaatlar (Support):</b>\n"
        f"• Jami: <b>{stats['total_tickets']}</b> ta\n"
        f"• Javob berilmagan: <b>{stats['unanswered_tickets']}</b> ta\n\n"
        f"👮 Adminlar soni: <b>{stats['total_admins']}</b> ta"
    )
    kb = InlineKeyboardMarkup(
        inline_keyboard=[[InlineKeyboardButton(text="🔙 Admin menyu", callback_data="adm_home")]]
    )
    await callback.message.edit_text(text, parse_mode="HTML", reply_markup=kb)
    await callback.answer()

# ===================================================================
# 3. ILOVA QO'SHISH (FSM WIZARD)
# ===================================================================

@router.callback_query(F.data == "adm_add_app")
async def start_add_app(callback: CallbackQuery, state: FSMContext, session: AsyncSession):
    """Yangi ilova qo'shishni boshlash."""
    is_adm, _ = await check_admin_access(callback.from_user.id, session)
    if not is_adm:
        await callback.answer("Ruxsat berilmagan!", show_alert=True)
        return

    await state.clear()
    await state.set_state(AddAppStates.waiting_for_title)

    kb = InlineKeyboardMarkup(
        inline_keyboard=[[InlineKeyboardButton(text="❌ Bekor qilish", callback_data="adm_home")]]
    )
    await callback.message.edit_text(
        "➕ <b>Yangi ilova qo'shish (1/9):</b>\n\nIlova nomini kiriting:",
        parse_mode="HTML",
        reply_markup=kb
    )
    await callback.answer()

@router.message(AddAppStates.waiting_for_title)
async def process_app_title(message: Message, state: FSMContext):
    is_valid, err = validate_app_title(message.text)
    if not is_valid:
        await message.answer(f"⚠️ {err}\nQaytadan kiriting:")
        return

    await state.update_data(title=message.text.strip())
    await state.set_state(AddAppStates.waiting_for_version)
    await message.answer(
        "🔢 <b>Ilova versiyasi (2/9):</b>\n\nVersiya raqamini kiriting (masalan: <code>1.0.0</code>):",
        parse_mode="HTML"
    )

@router.message(AddAppStates.waiting_for_version)
async def process_app_version(message: Message, state: FSMContext):
    is_valid, err = validate_version_number(message.text)
    if not is_valid:
        await message.answer(f"⚠️ {err}\nQaytadan kiriting:")
        return

    await state.update_data(version=message.text.strip())
    await state.set_state(AddAppStates.waiting_for_description)
    await message.answer(
        "📝 <b>Ilova haqida ma'lumot (3/9):</b>\n\nIlova tavsifini yozing:",
        parse_mode="HTML"
    )

@router.message(AddAppStates.waiting_for_description)
async def process_app_description(message: Message, state: FSMContext, session: AsyncSession):
    desc = message.text.strip()
    if len(desc) < 10:
        await message.answer("⚠️ Tavsif kamida 10 ta belgidan iborat bo'lishi kerak. Qaytadan yozing:")
        return

    await state.update_data(description=desc)
    await state.set_state(AddAppStates.waiting_for_category)

    # Kategoriyalarni inline chiqarish
    cat_repo = CategoryRepository(session)
    cats = await cat_repo.get_all_active()
    keyboard: list[list[InlineKeyboardButton]] = []
    row: list[InlineKeyboardButton] = []
    for c in cats:
        row.append(InlineKeyboardButton(text=f"{c.icon} {c.name}", callback_data=f"sel_cat_{c.id}"))
        if len(row) == 2:
            keyboard.append(row)
            row = []
    if row:
        keyboard.append(row)
    keyboard.append([InlineKeyboardButton(text="➡️ O'tkazib yuborish (Kategoriyasiz)", callback_data="sel_cat_0")])

    await message.answer(
        "🗂 <b>Ilova kategoriyasi (4/9):</b>\n\nQuyidagi kategoriyalardan birini tanlang:",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=keyboard)
    )

@router.callback_query(AddAppStates.waiting_for_category, F.data.startswith("sel_cat_"))
async def process_app_category(callback: CallbackQuery, state: FSMContext):
    cat_id = int(callback.data.split("sel_cat_")[1])
    await state.update_data(category_id=cat_id if cat_id > 0 else None)
    await state.set_state(AddAppStates.waiting_for_photo)

    kb = InlineKeyboardMarkup(
        inline_keyboard=[[InlineKeyboardButton(text="➡️ Rasmsiz davom etish", callback_data="skip_photo")]]
    )
    await callback.message.edit_text(
        "🖼 <b>Ilova logotipi yoki rasmi (5/9):</b>\n\n"
        "Ilova uchun rasm (photo) yuboring yoki o'tkazib yuborish tugmasini bosing:",
        parse_mode="HTML",
        reply_markup=kb
    )
    await callback.answer()

@router.message(AddAppStates.waiting_for_photo, F.photo)
async def process_app_photo(message: Message, state: FSMContext):
    photo_id = message.photo[-1].file_id
    await state.update_data(photo_file_id=photo_id)
    await ask_file_or_url(message, state)

@router.callback_query(AddAppStates.waiting_for_photo, F.data == "skip_photo")
async def process_skip_photo(callback: CallbackQuery, state: FSMContext):
    await state.update_data(photo_file_id=None)
    await callback.message.delete()
    await ask_file_or_url(callback.message, state)
    await callback.answer()

async def ask_file_or_url(message: Message, state: FSMContext):
    await state.set_state(AddAppStates.waiting_for_file_or_url)
    text = (
        "📦 <b>Ilova fayli yoki yuklab olish havolasi (6/9):</b>\n\n"
        "1. APK / dastur faylini Telegram orqali yuboring;\n"
        "YOKI\n"
        "2. Rasmiy yuklab olish havolasini (URL, masalan: <code>https://example.com/app.apk</code>) yozib yuboring:"
    )
    await message.answer(text, parse_mode="HTML")

@router.message(AddAppStates.waiting_for_file_or_url, F.document)
async def process_app_file(message: Message, state: FSMContext):
    doc: Document = message.document
    is_valid, err = validate_file_name(doc.file_name or "")
    if not is_valid:
        await message.answer(f"⚠️ {err}\nIltimos, ruxsat etilgan formatdagi fayl yuboring:")
        return

    size_formatted = format_file_size(doc.file_size or 0)
    await state.update_data(
        file_id=doc.file_id,
        download_url=None,
        file_size=size_formatted
    )
    await ask_platform(message, state)

@router.message(AddAppStates.waiting_for_file_or_url, F.text)
async def process_app_url(message: Message, state: FSMContext):
    url = message.text.strip()
    if not validate_url(url):
        await message.answer("⚠️ Noto'g'ri URL formati. Iltimos to'liq havola (http:// yoki https://) kiriting:")
        return

    await state.update_data(
        file_id=None,
        download_url=url,
        file_size="Tashqi havola"
    )
    await ask_platform(message, state)

async def ask_platform(message: Message, state: FSMContext):
    await state.set_state(AddAppStates.waiting_for_platform)
    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="🤖 Android (APK)", callback_data="plt_Android"),
                InlineKeyboardButton(text="🍏 iOS (IPA)", callback_data="plt_iOS"),
            ],
            [
                InlineKeyboardButton(text="💻 Windows (EXE/MSI)", callback_data="plt_Windows"),
                InlineKeyboardButton(text="🌐 Universal / Web", callback_data="plt_Universal"),
            ]
        ]
    )
    await message.answer(
        "💻 <b>Platforma (7/9):</b>\n\nQaysi operatsion tizim uchun mo'ljallangan?",
        parse_mode="HTML",
        reply_markup=kb
    )

@router.callback_query(AddAppStates.waiting_for_platform, F.data.startswith("plt_"))
async def process_platform(callback: CallbackQuery, state: FSMContext):
    platform = callback.data.split("plt_")[1]
    await state.update_data(platform=platform)
    await state.set_state(AddAppStates.waiting_for_status)

    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="🟢 Faol (Katalogda ko'rinadi)", callback_data="st_active"),
                InlineKeyboardButton(text="🔴 Yashirin (Ko'rinmaydi)", callback_data="st_hidden"),
            ]
        ]
    )
    await callback.message.edit_text(
        "👁 <b>Ilova holati (8/9):</b>\n\nIlova katalogda darhol faol bo'lsinmi?",
        parse_mode="HTML",
        reply_markup=kb
    )
    await callback.answer()

@router.callback_query(AddAppStates.waiting_for_status, F.data.startswith("st_"))
async def process_status_and_confirm(callback: CallbackQuery, state: FSMContext, session: AsyncSession):
    is_active = (callback.data == "st_active")
    await state.update_data(is_active=is_active)
    await state.set_state(AddAppStates.confirmation)

    data = await state.get_data()
    cat_name = "Kategoriyasiz"
    if data.get("category_id"):
        c = await CategoryRepository(session).get_by_id(data["category_id"])
        if c:
            cat_name = f"{c.icon} {c.name}"

    summary = (
        "📋 <b>Ilova ma'lumotlarini tekshiring (9/9):</b>\n\n"
        f"📱 <b>Nomi:</b> {safe_html(data.get('title'))}\n"
        f"🔢 <b>Versiyasi:</b> {safe_html(data.get('version'))}\n"
        f"🗂 <b>Kategoriya:</b> {safe_html(cat_name)}\n"
        f"💻 <b>Platforma:</b> {safe_html(data.get('platform'))}\n"
        f"💾 <b>Fayl/Hajm:</b> {safe_html(data.get('file_size'))}\n"
        f"👁 <b>Holati:</b> {'🟢 Faol' if is_active else '🔴 Yashirin'}\n\n"
        f"📝 <b>Tavsif:</b>\n{safe_html(data.get('description'))}\n\n"
        f"Ma'lumotlar to'g'rimi?"
    )
    await callback.message.edit_text(
        summary,
        parse_mode="HTML",
        reply_markup=get_save_cancel_keyboard("app_wizard")
    )
    await callback.answer()

@router.callback_query(AddAppStates.confirmation, F.data == "app_wizard_save")
async def save_new_app(callback: CallbackQuery, state: FSMContext, session: AsyncSession):
    """Yangi ilovani bazaga saqlash."""
    data = await state.get_data()
    app_service = AppService(session)
    log_repo = LogRepository(session)

    try:
        app = await app_service.create_app(
            title=data["title"],
            description=data["description"],
            category_id=data.get("category_id"),
            platform=data.get("platform", "Android"),
            photo_file_id=data.get("photo_file_id"),
            version_number=data["version"],
            file_id=data.get("file_id"),
            download_url=data.get("download_url"),
            file_size=data.get("file_size"),
            is_active=data.get("is_active", True)
        )
        await log_repo.log_admin_activity(
            admin_telegram_id=callback.from_user.id,
            action="ADD_APP",
            details=f"Yangi ilova qo'shildi: {app.title} (ID: {app.id})"
        )
        await session.commit()

        await state.clear()
        kb = InlineKeyboardMarkup(
            inline_keyboard=[
                [
                    InlineKeyboardButton(text="📱 Ilovani ko'rish", callback_data=f"adm_app_{app.id}"),
                    InlineKeyboardButton(text="➕ Yana qo'shish", callback_data="adm_add_app"),
                ],
                [InlineKeyboardButton(text="🔙 Admin menyu", callback_data="adm_home")]
            ]
        )
        await callback.message.edit_text(
            f"✅ <b>«{safe_html(app.title)}»</b> ilovasi muvaffaqiyatli saqlandi va katalogga qo'shildi!",
            parse_mode="HTML",
            reply_markup=kb
        )
    except Exception as e:
        logger.error(f"Ilova saqlashda xatolik: {e}", exc_info=True)
        await callback.message.edit_text(
            f"❌ Xatolik yuz berdi: {e}",
            reply_markup=InlineKeyboardMarkup(
                inline_keyboard=[[InlineKeyboardButton(text="🔙 Admin menyu", callback_data="adm_home")]]
            )
        )
    await callback.answer()

@router.callback_query(AddAppStates.confirmation, F.data == "app_wizard_retry")
async def retry_add_app(callback: CallbackQuery, state: FSMContext, session: AsyncSession):
    await start_add_app(callback, state, session)

@router.callback_query(AddAppStates.confirmation, F.data == "app_wizard_cancel")
async def cancel_add_app(callback: CallbackQuery, state: FSMContext, session: AsyncSession):
    await callback_adm_home(callback, session, state)

# ===================================================================
# 4. ILOVALARNI BOSHQARISH (EDIT, DELETE, TOGGLE, VERSION)
# ===================================================================

@router.callback_query(F.data.startswith("adm_manage_apps_"))
async def list_admin_apps(callback: CallbackQuery, session: AsyncSession):
    """Adminlar uchun ilovalar ro'yxati."""
    is_adm, _ = await check_admin_access(callback.from_user.id, session)
    if not is_adm:
        await callback.answer("Ruxsat berilmagan!", show_alert=True)
        return

    page = int(callback.data.split("adm_manage_apps_")[1])
    app_service = AppService(session)
    apps, total = await app_service.list_apps(page=page, limit=PAGE_LIMIT, only_active=False)

    text = f"📱 <b>Ilovalarni boshqarish</b> (Jami: {total} ta):\n\nTafsilotlar yoki tahrirlash uchun ilovani tanlang:"
    await callback.message.edit_text(
        text,
        parse_mode="HTML",
        reply_markup=get_admin_apps_keyboard(apps, page=page, total_count=total, limit=PAGE_LIMIT)
    )
    await callback.answer()

@router.callback_query(F.data.startswith("adm_app_"))
async def view_admin_single_app(callback: CallbackQuery, session: AsyncSession):
    """Bitta ilovani admin ko'rinishida chiqarish."""
    app_id = int(callback.data.split("adm_app_")[1])
    app_service = AppService(session)
    app = await app_service.get_app_details(app_id)

    if not app:
        await callback.answer("Ilova topilmadi.", show_alert=True)
        return

    latest_ver = app.versions[0] if app.versions else None
    cat_name = app.category.name if app.category else "Kategoriyasiz"

    text = (
        f"📱 <b>{safe_html(app.title)}</b> (ID: {app.id})\n\n"
        f"🗂 <b>Kategoriya:</b> {safe_html(cat_name)}\n"
        f"🔢 <b>Versiya:</b> {safe_html(latest_ver.version_number if latest_ver else 'Yoʻq')}\n"
        f"💻 <b>Platforma:</b> {safe_html(app.platform)}\n"
        f"💾 <b>Hajmi:</b> {safe_html(latest_ver.file_size if latest_ver else 'Noma\'lum')}\n"
        f"📥 <b>Yuklab olishlar:</b> {app.downloads_count} ta\n"
        f"👁 <b>Holati:</b> {'🟢 Faol' if app.is_active else '🔴 Yashirin'}\n"
        f"🕒 <b>Yangilangan:</b> {format_datetime(app.updated_at)}\n\n"
        f"📝 <b>Tavsif:</b>\n{safe_html(app.description)}"
    )
    try:
        await callback.message.delete()
    except Exception:
        pass

    if app.photo_file_id:
        try:
            await callback.message.answer_photo(
                photo=app.photo_file_id,
                caption=text,
                parse_mode="HTML",
                reply_markup=get_admin_app_detail_keyboard(app)
            )
            await callback.answer()
            return
        except Exception:
            pass

    await callback.message.answer(
        text,
        parse_mode="HTML",
        reply_markup=get_admin_app_detail_keyboard(app)
    )
    await callback.answer()

@router.callback_query(F.data.startswith("adm_toggle_app_"))
async def toggle_app_visibility(callback: CallbackQuery, session: AsyncSession):
    """Ilovani yashirish yoki faollashtirish."""
    app_id = int(callback.data.split("adm_toggle_app_")[1])
    app_service = AppService(session)
    log_repo = LogRepository(session)

    new_status = await app_service.toggle_app_status(app_id)
    if new_status is not None:
        status_word = "faollashtirildi" if new_status else "yashirildi"
        await log_repo.log_admin_activity(
            admin_telegram_id=callback.from_user.id,
            action="TOGGLE_APP_STATUS",
            details=f"Ilova ({app_id}) {status_word}"
        )
        await session.commit()
        await callback.answer(f"Ilova {status_word}!", show_alert=True)
        # Qayta ko'rsatish
        await view_admin_single_app(callback, session)

@router.callback_query(F.data.startswith("adm_del_app_confirm_"))
async def confirm_delete_app_dialog(callback: CallbackQuery):
    """O'chirishdan oldin tasdiqlash so'rash."""
    app_id = int(callback.data.split("adm_del_app_confirm_")[1])
    text = (
        "⚠️ <b>Haqiqatan ham ushbu ilovani o'chirib yubormoqchimisiz?</b>\n\n"
        "<i>Barcha bog'langan versiyalar va yuklab olish qaydlari ham o'chiriladi. "
        "Bu amalni ortga qaytarib bo'lmaydi!</i>"
    )
    await callback.message.answer(
        text,
        parse_mode="HTML",
        reply_markup=get_admin_delete_confirm_keyboard("app", app_id)
    )
    await callback.answer()

@router.callback_query(F.data.startswith("adm_confirm_del_app_"))
async def delete_app_confirmed(callback: CallbackQuery, session: AsyncSession):
    """Ilovani butunlay o'chirish."""
    app_id = int(callback.data.split("adm_confirm_del_app_")[1])
    app_service = AppService(session)
    log_repo = LogRepository(session)

    res = await app_service.delete_app(app_id)
    if res:
        await log_repo.log_admin_activity(
            admin_telegram_id=callback.from_user.id,
            action="DELETE_APP",
            details=f"Ilova o'chirildi (ID: {app_id})"
        )
        await session.commit()
        await callback.answer("Ilova muvaffaqiyatli o'chirildi!", show_alert=True)
    else:
        await callback.answer("Ilova topilmadi yoki allaqachon o'chirilgan.", show_alert=True)

    try:
        await callback.message.delete()
    except Exception:
        pass
    # Ro'yxatga qaytish
    apps, total = await app_service.list_apps(page=1, limit=PAGE_LIMIT, only_active=False)
    await callback.message.answer(
        f"📱 <b>Ilovalarni boshqarish</b> (Jami: {total} ta):",
        parse_mode="HTML",
        reply_markup=get_admin_apps_keyboard(apps, page=1, total_count=total, limit=PAGE_LIMIT)
    )

@router.callback_query(F.data.startswith("adm_cancel_del_app_"))
async def cancel_delete_app(callback: CallbackQuery):
    try:
        await callback.message.delete()
    except Exception:
        pass
    await callback.answer("O'chirish bekor qilindi.")

# Yangi versiya qo'shish
@router.callback_query(F.data.startswith("adm_new_ver_"))
async def start_add_version(callback: CallbackQuery, state: FSMContext):
    app_id = int(callback.data.split("adm_new_ver_")[1])
    await state.clear()
    await state.update_data(app_id=app_id)
    await state.set_state(AddVersionStates.waiting_for_version_number)

    await callback.message.answer(
        "🆕 <b>Yangi versiya raqamini kiriting:</b>\n<i>(Masalan: 2.0.1)</i>",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(
            inline_keyboard=[[InlineKeyboardButton(text="❌ Bekor qilish", callback_data=f"adm_app_{app_id}")]]
        )
    )
    await callback.answer()

@router.message(AddVersionStates.waiting_for_version_number)
async def process_new_version_num(message: Message, state: FSMContext):
    v = message.text.strip()
    is_valid, err = validate_version_number(v)
    if not is_valid:
        await message.answer(f"⚠️ {err}\nQaytadan kiriting:")
        return

    await state.update_data(version_number=v)
    await state.set_state(AddVersionStates.waiting_for_file_or_url)
    await message.answer(
        "📦 <b>Yangi versiya faylini (APK/ZIP) yuboring yoki havolasini yozing:</b>",
        parse_mode="HTML"
    )

@router.message(AddVersionStates.waiting_for_file_or_url, F.document)
async def process_new_version_file(message: Message, state: FSMContext, session: AsyncSession):
    doc = message.document
    data = await state.get_data()
    app_service = AppService(session)
    size_str = format_file_size(doc.file_size or 0)

    ver = await app_service.add_new_version(
        app_id=data["app_id"],
        version_number=data["version_number"],
        file_id=doc.file_id,
        download_url=None,
        file_size=size_str
    )
    await state.clear()
    await message.answer(
        f"✅ <b>Yangi versiya ({ver.version_number}) muvaffaqiyatli qo'shildi!</b>",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(
            inline_keyboard=[[InlineKeyboardButton(text="📱 Ilovaga qaytish", callback_data=f"adm_app_{data['app_id']}")]]
        )
    )

@router.message(AddVersionStates.waiting_for_file_or_url, F.text)
async def process_new_version_url(message: Message, state: FSMContext, session: AsyncSession):
    url = message.text.strip()
    if not validate_url(url):
        await message.answer("⚠️ Noto'g'ri URL formati. Qaytadan kiriting:")
        return

    data = await state.get_data()
    app_service = AppService(session)
    ver = await app_service.add_new_version(
        app_id=data["app_id"],
        version_number=data["version_number"],
        file_id=None,
        download_url=url,
        file_size="Tashqi havola"
    )
    await state.clear()
    await message.answer(
        f"✅ <b>Yangi versiya ({ver.version_number}) muvaffaqiyatli qo'shildi!</b>",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(
            inline_keyboard=[[InlineKeyboardButton(text="📱 Ilovaga qaytish", callback_data=f"adm_app_{data['app_id']}")]]
        )
    )

# ===================================================================
# 5. ADMINLARNI BOSHQARISH (FAQAT SUPERADMIN)
# ===================================================================

@router.callback_query(F.data == "adm_manage_admins")
async def list_admins(callback: CallbackQuery, session: AsyncSession):
    """Adminlar ro'yxati (Faqat Superadmin)."""
    _, is_super = await check_admin_access(callback.from_user.id, session)
    if not is_super:
        await callback.answer("⛔️ Ushbu bo'lim faqat SUPERADMIN uchun ruxsat etilgan!", show_alert=True)
        return

    admin_repo = AdminRepository(session)
    admins = await admin_repo.get_all()

    text = f"👮 <b>Adminlarni boshqarish</b> (Jami: {len(admins)} ta):\n\nKerakli adminni tanlang:"
    await callback.message.edit_text(
        text,
        parse_mode="HTML",
        reply_markup=get_admin_manage_admins_keyboard(admins)
    )
    await callback.answer()

@router.callback_query(F.data.startswith("adm_view_admin_"))
async def view_single_admin(callback: CallbackQuery, session: AsyncSession):
    admin_id = int(callback.data.split("adm_view_admin_")[1])
    admin_repo = AdminRepository(session)
    admin = await admin_repo.get_by_telegram_id(admin_id)

    if not admin:
        # Balki nofaol admin
        res = await session.execute(AdminRepository(session).session.query.__self__.select(AdminRepository).where(False)) if False else None
        admin = (await session.execute(
            AdminRepository(session).session.query.__self__.select(Admin).where(Admin.telegram_id == admin_id)
        )).scalar_one_or_none() if False else None

    # Oddiy qidiruv
    from database.models import Admin
    from sqlalchemy import select
    res = await session.execute(select(Admin).where(Admin.telegram_id == admin_id))
    admin = res.scalar_one_or_none()

    if not admin:
        await callback.answer("Admin topilmadi.", show_alert=True)
        return

    text = (
        f"👮 <b>Admin ma'lumotlari:</b>\n\n"
        f"👤 <b>Ism:</b> {safe_html(admin.full_name)}\n"
        f"🆔 <b>Telegram ID:</b> <code>{admin.telegram_id}</code>\n"
        f"🔗 <b>Username:</b> @{admin.username or 'yoʻq'}\n"
        f"🎖 <b>Roli:</b> <b>{admin.role}</b>\n"
        f"⚡️ <b>Holati:</b> {'🟢 Faol' if admin.is_active else '🔴 Bloklangan'}\n"
        f"🕒 <b>Qo'shilgan:</b> {format_datetime(admin.created_at)}"
    )
    await callback.message.edit_text(
        text,
        parse_mode="HTML",
        reply_markup=get_admin_single_manage_keyboard(admin)
    )
    await callback.answer()

@router.callback_query(F.data.startswith("adm_toggle_admin_"))
async def toggle_admin_status(callback: CallbackQuery, session: AsyncSession):
    _, is_super = await check_admin_access(callback.from_user.id, session)
    if not is_super:
        await callback.answer("Ruxsat berilmagan!", show_alert=True)
        return

    admin_id = int(callback.data.split("adm_toggle_admin_")[1])
    admin_repo = AdminRepository(session)
    new_st = await admin_repo.toggle_status(admin_id)
    if new_st is None:
        await callback.answer("Superadmin statusini o'zgartirib bo'lmaydi!", show_alert=True)
        return

    await session.commit()
    await callback.answer(f"Admin holati o'zgartirildi: {'Faol' if new_st else 'Bloklandi'}!")
    await list_admins(callback, session)

@router.callback_query(F.data.startswith("adm_del_admin_confirm_"))
async def confirm_delete_admin(callback: CallbackQuery, session: AsyncSession):
    _, is_super = await check_admin_access(callback.from_user.id, session)
    if not is_super:
        await callback.answer("Ruxsat yo'q!", show_alert=True)
        return

    admin_id = int(callback.data.split("adm_del_admin_confirm_")[1])
    text = f"⚠️ <b>Haqiqatan ham ID: <code>{admin_id}</code> bo'lgan adminlik huquqini bekor qilmoqchimisiz?</b>"
    await callback.message.edit_text(
        text,
        parse_mode="HTML",
        reply_markup=get_admin_delete_confirm_keyboard("admin", admin_id)
    )
    await callback.answer()

@router.callback_query(F.data.startswith("adm_confirm_del_admin_"))
async def delete_admin_confirmed(callback: CallbackQuery, session: AsyncSession):
    admin_id = int(callback.data.split("adm_confirm_del_admin_")[1])
    admin_repo = AdminRepository(session)
    success = await admin_repo.remove_admin(admin_id)
    if success:
        await session.commit()
        await callback.answer("Admin muvaffaqiyatli o'chirildi!", show_alert=True)
    else:
        await callback.answer("Superadminni o'chirib bo'lmaydi yoki admin topilmadi!", show_alert=True)
    await list_admins(callback, session)

@router.callback_query(F.data.startswith("adm_cancel_del_admin_"))
async def cancel_del_admin(callback: CallbackQuery, session: AsyncSession):
    await list_admins(callback, session)

@router.callback_query(F.data == "adm_add_new_admin")
async def start_add_admin(callback: CallbackQuery, state: FSMContext, session: AsyncSession):
    _, is_super = await check_admin_access(callback.from_user.id, session)
    if not is_super:
        await callback.answer("Faqat superadmin yangi admin qo'sha oladi!", show_alert=True)
        return

    await state.clear()
    await state.set_state(ManageAdminStates.waiting_for_admin_id)
    kb = InlineKeyboardMarkup(
        inline_keyboard=[[InlineKeyboardButton(text="❌ Bekor qilish", callback_data="adm_manage_admins")]]
    )
    await callback.message.edit_text(
        "👮 <b>Yangi admin qo'shish:</b>\n\nBo'lajak adminning <b>Telegram ID</b> raqamini yuboring:\n<i>(Masalan: 123456789)</i>",
        parse_mode="HTML",
        reply_markup=kb
    )
    await callback.answer()

@router.message(ManageAdminStates.waiting_for_admin_id)
async def process_new_admin_id(message: Message, state: FSMContext):
    try:
        tg_id = int(message.text.strip())
    except ValueError:
        await message.answer("⚠️ Telegram ID faqat raqamlardan iborat bo'lishi kerak. Qaytadan kiriting:")
        return

    await state.update_data(admin_tg_id=tg_id)
    await state.set_state(ManageAdminStates.waiting_for_name)
    await message.answer("👤 Adminning to'liq ism-sharifini kiriting:")

@router.message(ManageAdminStates.waiting_for_name)
async def process_new_admin_name(message: Message, state: FSMContext, session: AsyncSession):
    name = message.text.strip()
    data = await state.get_data()
    tg_id = data["admin_tg_id"]

    admin_repo = AdminRepository(session)
    await admin_repo.add_admin(
        telegram_id=tg_id,
        full_name=name,
        role="ADMIN"
    )
    await session.commit()
    await state.clear()

    await message.answer(
        f"✅ <b>{safe_html(name)}</b> (ID: <code>{tg_id}</code>) muvaffaqiyatli ADMIN etib tayinlandi!",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(
            inline_keyboard=[[InlineKeyboardButton(text="🔙 Adminlar ro'yxati", callback_data="adm_manage_admins")]]
        )
    )

# ===================================================================
# 6. KANALLARNI BOSHQARISH
# ===================================================================

@router.callback_query(F.data == "adm_manage_channels")
async def list_admin_channels(callback: CallbackQuery, session: AsyncSession):
    """Kanallar ro'yxati."""
    is_adm, _ = await check_admin_access(callback.from_user.id, session)
    if not is_adm:
        await callback.answer("Ruxsat yo'q!", show_alert=True)
        return

    ch_repo = ChannelRepository(session)
    channels = await ch_repo.get_all()

    text = f"📢 <b>Ulangan kanallar boshqaruvi</b> (Jami: {len(channels)} ta):\n\nKerakli kanalni tanlang:"
    await callback.message.edit_text(
        text,
        parse_mode="HTML",
        reply_markup=get_admin_channels_keyboard(channels)
    )
    await callback.answer()

@router.callback_query(F.data.startswith("adm_ch_"))
async def view_admin_single_channel(callback: CallbackQuery, session: AsyncSession):
    ch_id = int(callback.data.split("adm_ch_")[1])
    ch_repo = ChannelRepository(session)
    channel = await ch_repo.get_by_id(ch_id)

    if not channel:
        await callback.answer("Kanal topilmadi.", show_alert=True)
        return

    text = (
        f"📢 <b>Kanal ma'lumotlari:</b>\n\n"
        f"📌 <b>Nomi:</b> {safe_html(channel.title)}\n"
        f"🆔 <b>Kanal ID:</b> <code>{channel.channel_id}</code>\n"
        f"🔗 <b>Username/Havola:</b> {channel.username or channel.invite_link or 'Ko\'rsatilmagan'}\n"
        f"📋 <b>Turi:</b> <b>{channel.channel_type}</b>\n"
        f"⚡️ <b>Holati:</b> {'🟢 Faol' if channel.is_active else '🔴 Nofaol'}"
    )
    await callback.message.edit_text(
        text,
        parse_mode="HTML",
        reply_markup=get_admin_channel_detail_keyboard(channel)
    )
    await callback.answer()

@router.callback_query(F.data.startswith("adm_toggle_ch_"))
async def toggle_channel_status(callback: CallbackQuery, session: AsyncSession):
    ch_id = int(callback.data.split("adm_toggle_ch_")[1])
    ch_repo = ChannelRepository(session)
    new_st = await ch_repo.toggle_status(ch_id)
    if new_st is not None:
        await session.commit()
        await callback.answer(f"Kanal holati: {'Faol' if new_st else 'Nofaol'}!")
        await list_admin_channels(callback, session)

@router.callback_query(F.data.startswith("adm_del_ch_confirm_"))
async def confirm_delete_channel(callback: CallbackQuery):
    ch_id = int(callback.data.split("adm_del_ch_confirm_")[1])
    text = "⚠️ <b>Haqiqatan ham ushbu kanalni tizimdan o'chirmoqchimisiz?</b>"
    await callback.message.edit_text(
        text,
        parse_mode="HTML",
        reply_markup=get_admin_delete_confirm_keyboard("channel", ch_id)
    )
    await callback.answer()

@router.callback_query(F.data.startswith("adm_confirm_del_channel_"))
async def delete_channel_confirmed(callback: CallbackQuery, session: AsyncSession):
    ch_id = int(callback.data.split("adm_confirm_del_channel_")[1])
    ch_repo = ChannelRepository(session)
    await ch_repo.delete(ch_id)
    await session.commit()
    await callback.answer("Kanal o'chirildi!", show_alert=True)
    await list_admin_channels(callback, session)

@router.callback_query(F.data.startswith("adm_cancel_del_channel_"))
async def cancel_delete_channel(callback: CallbackQuery, session: AsyncSession):
    await list_admin_channels(callback, session)

@router.callback_query(F.data == "adm_add_channel")
async def start_add_channel(callback: CallbackQuery, state: FSMContext):
    await state.clear()
    await state.set_state(ManageChannelStates.waiting_for_title)
    kb = InlineKeyboardMarkup(
        inline_keyboard=[[InlineKeyboardButton(text="❌ Bekor qilish", callback_data="adm_manage_channels")]]
    )
    await callback.message.edit_text(
        "📢 <b>Yangi kanal qo'shish (1/4):</b>\n\nKanal nomini kiriting:",
        parse_mode="HTML",
        reply_markup=kb
    )
    await callback.answer()

@router.message(ManageChannelStates.waiting_for_title)
async def process_channel_title(message: Message, state: FSMContext):
    await state.update_data(title=message.text.strip())
    await state.set_state(ManageChannelStates.waiting_for_channel_id)
    await message.answer(
        "🆔 <b>Kanal ID raqami (2/4):</b>\n\n"
        "Kanalning Telegram ID sini kiriting (odatda -100 bilan boshlanadi, masalan: <code>-1001234567890</code>):\n"
        "<i>(Bot ushbu kanalda administrator bo'lishi shart!)</i>",
        parse_mode="HTML"
    )

@router.message(ManageChannelStates.waiting_for_channel_id)
async def process_channel_id(message: Message, state: FSMContext):
    try:
        cid = int(message.text.strip())
    except ValueError:
        await message.answer("⚠️ ID faqat butun sondan iborat bo'lishi kerak. Qaytadan kiriting:")
        return

    await state.update_data(channel_id=cid)
    await state.set_state(ManageChannelStates.waiting_for_link)
    await message.answer(
        "🔗 <b>Kanal havolasi yoki username (3/4):</b>\n\n"
        "Masalan: <code>@meningkanalim</code> yoki taklif havolasi (<code>https://t.me/+AbCdEfGh</code>):",
        parse_mode="HTML"
    )

@router.message(ManageChannelStates.waiting_for_link)
async def process_channel_link(message: Message, state: FSMContext):
    link = message.text.strip()
    await state.update_data(link=link)
    await state.set_state(ManageChannelStates.select_type)

    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="📢 Majburiy obuna kanali", callback_data="chtype_MANDATORY")],
            [InlineKeyboardButton(text="📩 Zayavka (Request) kanali", callback_data="chtype_REQUEST")],
            [InlineKeyboardButton(text="⭐️ Asosiy kanal", callback_data="chtype_ASOSIY")],
        ]
    )
    await message.answer(
        "📋 <b>Kanal turini tanlang (4/4):</b>",
        parse_mode="HTML",
        reply_markup=kb
    )

@router.callback_query(ManageChannelStates.select_type, F.data.startswith("chtype_"))
async def finish_add_channel(callback: CallbackQuery, state: FSMContext, session: AsyncSession):
    ctype = callback.data.split("chtype_")[1]
    data = await state.get_data()
    ch_repo = ChannelRepository(session)

    link = data.get("link", "")
    username = link if link.startswith("@") else None
    invite_link = link if not link.startswith("@") else None

    await ch_repo.add_channel(
        title=data["title"],
        channel_id=data["channel_id"],
        username=username,
        invite_link=invite_link,
        channel_type=ctype
    )
    await session.commit()
    await state.clear()

    await callback.message.edit_text(
        f"✅ <b>«{safe_html(data['title'])}»</b> kanali muvaffaqiyatli qo'shildi!",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(
            inline_keyboard=[[InlineKeyboardButton(text="🔙 Kanallar ro'yxati", callback_data="adm_manage_channels")]]
        )
    )
    await callback.answer()

# ===================================================================
# 7. FOYDALANUVCHI MUROJAATLARI (SUPPORT)
# ===================================================================

@router.callback_query(F.data.startswith("adm_support_"))
async def list_support_tickets(callback: CallbackQuery, session: AsyncSession):
    """Murojaatlar ro'yxati."""
    is_adm, _ = await check_admin_access(callback.from_user.id, session)
    if not is_adm:
        await callback.answer("Ruxsat berilmagan!", show_alert=True)
        return

    page = int(callback.data.split("adm_support_")[1])
    sup_service = SupportService(session)
    tickets, total = await sup_service.get_tickets(page=page, limit=8)

    text = f"✉️ <b>Foydalanuvchi murojaatlari</b> (Jami: {total} ta):\n\nKerakli chiptani tanlang:"
    await callback.message.edit_text(
        text,
        parse_mode="HTML",
        reply_markup=get_admin_support_tickets_keyboard(tickets, page=page, total_count=total, limit=8)
    )
    await callback.answer()

@router.callback_query(F.data.startswith("adm_ticket_"))
async def view_single_ticket(callback: CallbackQuery, session: AsyncSession):
    ticket_id = int(callback.data.split("adm_ticket_")[1])
    sup_service = SupportService(session)
    ticket = await sup_service.get_ticket(ticket_id)

    if not ticket:
        await callback.answer("Chipta topilmadi.", show_alert=True)
        return

    msg_history = ""
    for m in ticket.messages:
        sender_label = "👤 Foydalanuvchi" if m.sender_type == "USER" else "👨‍💻 Admin"
        msg_history += f"<b>{sender_label}</b> ({format_datetime(m.created_at)}):\n{safe_html(m.message_text)}\n\n"

    text = (
        f"🎫 <b>Chipta:</b> <code>{ticket.ticket_number}</code>\n"
        f"👤 <b>Foydalanuvchi:</b> <code>{ticket.user_id}</code>\n"
        f"📌 <b>Mavzu:</b> {safe_html(ticket.subject)}\n"
        f"⚡️ <b>Holat:</b> <b>{ticket.status}</b>\n\n"
        f"💬 <b>Suhbat tarixi:</b>\n{msg_history}"
    )
    await callback.message.edit_text(
        text,
        parse_mode="HTML",
        reply_markup=get_admin_ticket_actions_keyboard(ticket.id, ticket.status)
    )
    await callback.answer()

@router.callback_query(F.data.startswith("adm_reply_ticket_"))
async def start_reply_ticket(callback: CallbackQuery, state: FSMContext):
    ticket_id = int(callback.data.split("adm_reply_ticket_")[1])
    await state.clear()
    await state.update_data(ticket_id=ticket_id)
    await state.set_state(SupportReplyStates.waiting_for_reply_text)

    await callback.message.answer(
        "✍️ <b>Foydalanuvchiga yuboriladigan javob matnini yozing:</b>",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(
            inline_keyboard=[[InlineKeyboardButton(text="❌ Bekor qilish", callback_data=f"adm_ticket_{ticket_id}")]]
        )
    )
    await callback.answer()

@router.message(SupportReplyStates.waiting_for_reply_text)
async def process_ticket_reply(message: Message, bot: Bot, state: FSMContext, session: AsyncSession):
    reply_text = message.text.strip() if message.text else ""
    if not reply_text:
        await message.answer("⚠️ Javob matni bo'sh bo'lishi mumkin emas. Qaytadan yozing:")
        return

    data = await state.get_data()
    ticket_id = data["ticket_id"]
    sup_service = SupportService(session)

    ok, err = await sup_service.send_reply(
        bot=bot,
        ticket_id=ticket_id,
        admin_id=message.from_user.id,
        reply_text=reply_text
    )
    await state.clear()

    if ok:
        await message.answer(
            "✅ <b>Javob foydalanuvchiga muvaffaqiyatli yetkazildi!</b>",
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup(
                inline_keyboard=[[InlineKeyboardButton(text="🔙 Chiptaga qaytish", callback_data=f"adm_ticket_{ticket_id}")]]
            )
        )
    else:
        await message.answer(
            f"⚠️ Javob saqlandi, lekin foydalanuvchiga yetkazilmadi: {err}",
            reply_markup=InlineKeyboardMarkup(
                inline_keyboard=[[InlineKeyboardButton(text="🔙 Chiptaga qaytish", callback_data=f"adm_ticket_{ticket_id}")]]
            )
        )

@router.callback_query(F.data.startswith("adm_close_ticket_"))
async def close_ticket_action(callback: CallbackQuery, session: AsyncSession):
    ticket_id = int(callback.data.split("adm_close_ticket_")[1])
    sup_service = SupportService(session)
    await sup_service.close_ticket(ticket_id)
    await callback.answer("Chipta yopildi!", show_alert=True)
    await view_single_ticket(callback, session)

# ===================================================================
# 8. BOT ORQALI XABAR YUBORISH (BROADCAST)
# ===================================================================

@router.callback_query(F.data == "adm_broadcast")
async def start_broadcast(callback: CallbackQuery, state: FSMContext, session: AsyncSession):
    is_adm, _ = await check_admin_access(callback.from_user.id, session)
    if not is_adm:
        await callback.answer("Ruxsat yo'q!", show_alert=True)
        return

    await state.clear()
    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="📢 Barcha foydalanuvchilarga", callback_data="bc_target_all")],
            [InlineKeyboardButton(text="👤 Bitta foydalanuvchiga (ID orqali)", callback_data="bc_target_single")],
            [InlineKeyboardButton(text="🔙 Admin menyu", callback_data="adm_home")],
        ]
    )
    await callback.message.edit_text(
        "📨 <b>Bot orqali xabar yuborish bo'limi:</b>\n\nKimga xabar yubormoqchisiz?",
        parse_mode="HTML",
        reply_markup=kb
    )
    await callback.answer()

@router.callback_query(F.data == "bc_target_all")
async def broadcast_choose_all(callback: CallbackQuery, state: FSMContext):
    await state.update_data(target_type="all")
    await state.set_state(BroadcastStates.waiting_for_content)
    await callback.message.edit_text(
        "📝 <b>Xabar matnini yoki rasm+matn yuboring:</b>\n\n<i>(HTML format qo'llab-quvvatlanadi)</i>",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(
            inline_keyboard=[[InlineKeyboardButton(text="❌ Bekor qilish", callback_data="adm_broadcast")]]
        )
    )
    await callback.answer()

@router.callback_query(F.data == "bc_target_single")
async def broadcast_choose_single(callback: CallbackQuery, state: FSMContext):
    await state.update_data(target_type="single")
    await state.set_state(BroadcastStates.waiting_for_target_id)
    await callback.message.edit_text(
        "👤 <b>Foydalanuvchining Telegram ID sini kiriting:</b>",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(
            inline_keyboard=[[InlineKeyboardButton(text="❌ Bekor qilish", callback_data="adm_broadcast")]]
        )
    )
    await callback.answer()

@router.message(BroadcastStates.waiting_for_target_id)
async def process_bc_single_id(message: Message, state: FSMContext):
    try:
        uid = int(message.text.strip())
    except ValueError:
        await message.answer("⚠️ ID faqat raqamlardan iborat bo'lishi kerak. Qaytadan kiriting:")
        return

    await state.update_data(target_user_id=uid)
    await state.set_state(BroadcastStates.waiting_for_content)
    await message.answer(
        f"✅ Qabul qiluvchi ID: <code>{uid}</code>\n\nEndi yuboriladigan xabar matnini yoki rasm+matnni yuboring:",
        parse_mode="HTML"
    )

@router.message(BroadcastStates.waiting_for_content, F.text)
async def process_bc_content_text(message: Message, state: FSMContext):
    await state.update_data(content=message.text, photo_file_id=None)
    await show_bc_preview(message, state)

@router.message(BroadcastStates.waiting_for_content, F.photo)
async def process_bc_content_photo(message: Message, state: FSMContext):
    photo_id = message.photo[-1].file_id
    caption = message.caption or ""
    await state.update_data(content=caption, photo_file_id=photo_id)
    await show_bc_preview(message, state)

async def show_bc_preview(message: Message, state: FSMContext):
    data = await state.get_data()
    await state.set_state(BroadcastStates.confirmation)

    preview_note = "🔍 <b>Oldindan ko'rish (Preview):</b>\n" + ("=" * 25) + "\n\n"
    if data.get("photo_file_id"):
        await message.answer_photo(
            photo=data["photo_file_id"],
            caption=preview_note + data.get("content", ""),
            parse_mode="HTML",
            reply_markup=get_broadcast_confirm_keyboard()
        )
    else:
        await message.answer(
            preview_note + data.get("content", ""),
            parse_mode="HTML",
            reply_markup=get_broadcast_confirm_keyboard()
        )

@router.callback_query(BroadcastStates.confirmation, F.data == "bc_confirm_send")
async def execute_broadcast(callback: CallbackQuery, bot: Bot, state: FSMContext, session: AsyncSession):
    data = await state.get_data()
    bc_service = BroadcastService(session)
    log_repo = LogRepository(session)

    await callback.message.edit_reply_markup(reply_markup=None)
    status_msg = await callback.message.answer("⏳ <i>Xabar yuborish boshlandi, iltimos kuting...</i>", parse_mode="HTML")

    if data.get("target_type") == "single":
        user_id = data["target_user_id"]
        ok = await bc_service.send_to_single_user(
            bot=bot,
            user_id=user_id,
            text=data.get("content", ""),
            photo_file_id=data.get("photo_file_id")
        )
        await state.clear()
        if ok:
            await status_msg.edit_text(f"✅ Xabar foydalanuvchiga (<code>{user_id}</code>) yetkazildi!", parse_mode="HTML")
        else:
            await status_msg.edit_text(f"❌ Xabarni foydalanuvchiga (<code>{user_id}</code>) yetkazib bo'lmadi (bot bloklangan bo'lishi mumkin).", parse_mode="HTML")
    else:
        # Barchaga tarqatish
        report = await bc_service.broadcast_to_all(
            bot=bot,
            admin_telegram_id=callback.from_user.id,
            text=data.get("content", ""),
            photo_file_id=data.get("photo_file_id")
        )
        await log_repo.log_admin_activity(
            admin_telegram_id=callback.from_user.id,
            action="BROADCAST_ALL",
            details=f"Ommaviy xabar: {report['sent']} ta yetdi, {report['failed']} ta yetmadi"
        )
        await session.commit()
        await state.clear()

        report_text = (
            f"🎉 <b>Ommaviy xabar yuborish yakunlandi!</b>\n\n"
            f"🎯 Jami maqsad: <b>{report['total']}</b> ta\n"
            f"✅ Yetkazildi: <b>{report['sent']}</b> ta\n"
            f"🚫 Bloklagan/yetmagan: <b>{report['failed']}</b> ta"
        )
        await status_msg.edit_text(
            report_text,
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup(
                inline_keyboard=[[InlineKeyboardButton(text="🔙 Admin menyu", callback_data="adm_home")]]
            )
        )
    await callback.answer()

@router.callback_query(BroadcastStates.confirmation, F.data == "bc_cancel")
async def cancel_broadcast(callback: CallbackQuery, state: FSMContext, session: AsyncSession):
    await callback_adm_home(callback, session, state)

# ===================================================================
# 9. KATEGORIYALARNI BOSHQARISH
# ===================================================================

@router.callback_query(F.data == "adm_manage_cats")
async def list_admin_categories(callback: CallbackQuery, session: AsyncSession):
    is_adm, _ = await check_admin_access(callback.from_user.id, session)
    if not is_adm:
        await callback.answer("Ruxsat yo'q!", show_alert=True)
        return

    cat_repo = CategoryRepository(session)
    cats = await cat_repo.get_all()

    text = f"🗂 <b>Kategoriyalarni boshqarish</b> (Jami: {len(cats)} ta):\n\nKerakli kategoriyani tanlang:"
    await callback.message.edit_text(
        text,
        parse_mode="HTML",
        reply_markup=get_admin_categories_keyboard(cats)
    )
    await callback.answer()

@router.callback_query(F.data.startswith("adm_cat_"))
async def view_admin_single_category(callback: CallbackQuery, session: AsyncSession):
    cat_id = int(callback.data.split("adm_cat_")[1])
    cat_repo = CategoryRepository(session)
    cat = await cat_repo.get_by_id(cat_id)

    if not cat:
        await callback.answer("Kategoriya topilmadi.", show_alert=True)
        return

    text = (
        f"🗂 <b>Kategoriya ma'lumotlari:</b>\n\n"
        f"📌 <b>Nomi:</b> {cat.icon} {safe_html(cat.name)}\n"
        f"🔗 <b>Slug:</b> <code>{cat.slug}</code>\n"
        f"⚡️ <b>Holati:</b> {'🟢 Faol' if cat.is_active else '🔴 Nofaol'}"
    )
    await callback.message.edit_text(
        text,
        parse_mode="HTML",
        reply_markup=get_admin_category_detail_keyboard(cat)
    )
    await callback.answer()

@router.callback_query(F.data.startswith("adm_toggle_cat_"))
async def toggle_category_status(callback: CallbackQuery, session: AsyncSession):
    cat_id = int(callback.data.split("adm_toggle_cat_")[1])
    cat_repo = CategoryRepository(session)
    cat = await cat_repo.get_by_id(cat_id)
    if cat:
        await cat_repo.update(cat_id, is_active=not cat.is_active)
        await session.commit()
        await callback.answer("Kategoriya holati yangilandi!")
        await list_admin_categories(callback, session)

@router.callback_query(F.data.startswith("adm_del_cat_confirm_"))
async def confirm_delete_cat(callback: CallbackQuery):
    cat_id = int(callback.data.split("adm_del_cat_confirm_")[1])
    text = "⚠️ <b>Haqiqatan ham ushbu kategoriyani o'chirmoqchimisiz?</b>\n<i>(Unga tegishli ilovalar kategoriyasiz holatga o'tadi)</i>"
    await callback.message.edit_text(
        text,
        parse_mode="HTML",
        reply_markup=get_admin_delete_confirm_keyboard("category", cat_id)
    )
    await callback.answer()

@router.callback_query(F.data.startswith("adm_confirm_del_category_"))
async def delete_category_confirmed(callback: CallbackQuery, session: AsyncSession):
    cat_id = int(callback.data.split("adm_confirm_del_category_")[1])
    cat_repo = CategoryRepository(session)
    await cat_repo.delete(cat_id)
    await session.commit()
    await callback.answer("Kategoriya o'chirildi!", show_alert=True)
    await list_admin_categories(callback, session)

@router.callback_query(F.data.startswith("adm_cancel_del_category_"))
async def cancel_delete_cat(callback: CallbackQuery, session: AsyncSession):
    await list_admin_categories(callback, session)

@router.callback_query(F.data == "adm_add_cat")
async def start_add_category(callback: CallbackQuery, state: FSMContext):
    await state.clear()
    await state.set_state(ManageCategoryStates.waiting_for_name)
    kb = InlineKeyboardMarkup(
        inline_keyboard=[[InlineKeyboardButton(text="❌ Bekor qilish", callback_data="adm_manage_cats")]]
    )
    await callback.message.edit_text(
        "🗂 <b>Yangi kategoriya qo'shish (1/2):</b>\n\nKategoriya nomini kiriting:",
        parse_mode="HTML",
        reply_markup=kb
    )
    await callback.answer()

@router.message(ManageCategoryStates.waiting_for_name)
async def process_cat_name(message: Message, state: FSMContext):
    name = message.text.strip()
    if len(name) < 2:
        await message.answer("⚠️ Kategoriya nomi kamida 2 ta belgi bo'lishi kerak. Qaytadan kiriting:")
        return

    await state.update_data(name=name)
    await state.set_state(ManageCategoryStates.waiting_for_icon)
    await message.answer("📁 Kategoriya uchun bitta emoji ikonka kiriting (masalan: 🎮, 📱, 📚):")

@router.message(ManageCategoryStates.waiting_for_icon)
async def process_cat_icon(message: Message, state: FSMContext, session: AsyncSession):
    icon = message.text.strip()[:5]
    data = await state.get_data()
    name = data["name"]

    cat_repo = CategoryRepository(session)
    slug = slugify(name)
    await cat_repo.create(name=name, slug=slug, icon=icon)
    await session.commit()
    await state.clear()

    await message.answer(
        f"✅ <b>{icon} {safe_html(name)}</b> kategoriyasi muvaffaqiyatli qo'shildi!",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(
            inline_keyboard=[[InlineKeyboardButton(text="🔙 Kategoriyalar ro'yxati", callback_data="adm_manage_cats")]]
        )
    )

# ===================================================================
# 10. BOT SOZLAMALARI
# ===================================================================

@router.callback_query(F.data == "adm_settings")
async def show_bot_settings(callback: CallbackQuery, session: AsyncSession):
    is_adm, _ = await check_admin_access(callback.from_user.id, session)
    if not is_adm:
        await callback.answer("Ruxsat yo'q!", show_alert=True)
        return

    setting_repo = SettingRepository(session)
    sub_val = await setting_repo.get("mandatory_subscription", "true")
    maint_val = await setting_repo.get("maintenance_mode", "false")

    sub_enabled = sub_val.lower() in ("true", "1", "yes")
    maint_enabled = maint_val.lower() in ("true", "1", "yes")

    text = (
        "⚙️ <b>Bot tizim sozlamalari:</b>\n\n"
        "Quyidagi tugmalar orqali asosiy rejimlarni o'zgartirishingiz mumkin:"
    )
    await callback.message.edit_text(
        text,
        parse_mode="HTML",
        reply_markup=get_admin_settings_keyboard(sub_enabled, maint_enabled)
    )
    await callback.answer()

@router.callback_query(F.data == "adm_toggle_setting_sub")
async def toggle_sub_setting(callback: CallbackQuery, session: AsyncSession):
    setting_repo = SettingRepository(session)
    current = await setting_repo.get("mandatory_subscription", "true")
    new_val = "false" if current.lower() in ("true", "1", "yes") else "true"
    await setting_repo.set("mandatory_subscription", new_val)
    await session.commit()
    await callback.answer(f"Majburiy obuna: {'YOQILDI' if new_val == 'true' else 'O\'CHIRILDI'}!")
    await show_bot_settings(callback, session)

@router.callback_query(F.data == "adm_toggle_setting_maint")
async def toggle_maint_setting(callback: CallbackQuery, session: AsyncSession):
    setting_repo = SettingRepository(session)
    current = await setting_repo.get("maintenance_mode", "false")
    new_val = "false" if current.lower() in ("true", "1", "yes") else "true"
    await setting_repo.set("maintenance_mode", new_val)
    await session.commit()
    await callback.answer(f"Texnik tanaffus: {'YOQILDI' if new_val == 'true' else 'O\'CHIRILDI'}!")
    await show_bot_settings(callback, session)
