import logging
from aiogram import Router, F, Bot
from aiogram.types import CallbackQuery
from sqlalchemy.ext.asyncio import AsyncSession

from database.repositories import AdminRepository
from keyboards.user import get_main_reply_keyboard, get_subscription_keyboard
from services.channel_service import ChannelService

logger = logging.getLogger(__name__)

router = Router(name="subscriptions_router")

@router.callback_query(F.data == "check_subscription")
async def process_check_subscription(callback: CallbackQuery, bot: Bot, session: AsyncSession):
    """Foydalanuvchi obuna bo'lganini qayta tekshirish."""
    user_id = callback.from_user.id
    channel_service = ChannelService(session)
    admin_repo = AdminRepository(session)

    is_subscribed, missing_channels = await channel_service.check_user_subscription(bot, user_id)

    if is_subscribed:
        is_admin = await admin_repo.is_admin(user_id)
        try:
            await callback.message.delete()
        except Exception:
            pass

        await callback.message.answer(
            "🎉 **Rahmat! Obunangiz tasdiqlandi.**\n\n"
            "Endi botning barcha imkoniyatlaridan to'liq foydalanishingiz mumkin!",
            parse_mode="Markdown",
            reply_markup=get_main_reply_keyboard(is_admin=is_admin)
        )
        await callback.answer("Obuna tasdiqlandi!")
    else:
        await callback.answer(
            "⚠️ Siz hali barcha kanallarga a'zo bo'lmadingiz. Iltimos, barcha kanallarga a'zo bo'ling!",
            show_alert=True
        )
        try:
            await callback.message.edit_reply_markup(
                reply_markup=get_subscription_keyboard(missing_channels)
            )
        except Exception:
            pass
