from typing import Callable, Dict, Any, Awaitable
from aiogram import BaseMiddleware
from aiogram.types import TelegramObject, User as TgUser
from database.database import AsyncSessionFactory
from database.repositories import UserRepository

class DbSessionMiddleware(BaseMiddleware):
    async def __call__(
        self,
        handler: Callable[[TelegramObject, Dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: Dict[str, Any]
    ) -> Any:
        async with AsyncSessionFactory() as session:
            data["session"] = session
            try:
                # Agar event ichida foydalanuvchi bo'lsa uni ro'yxatdan o'tkazish/yangilash
                event_from_user: TgUser = data.get("event_from_user")
                if event_from_user and not event_from_user.is_bot:
                    user_repo = UserRepository(session)
                    user = await user_repo.register_or_update(
                        telegram_id=event_from_user.id,
                        first_name=event_from_user.first_name,
                        last_name=event_from_user.last_name,
                        username=event_from_user.username,
                        language_code=event_from_user.language_code or "uz"
                    )
                    data["user"] = user

                result = await handler(event, data)
                await session.commit()
                return result
            except Exception:
                await session.rollback()
                raise
            finally:
                await session.close()
