import logging
from typing import Callable, Dict, Any, Awaitable
from aiogram import BaseMiddleware
from aiogram.types import TelegramObject, Message, CallbackQuery
from sqlalchemy.ext.asyncio import AsyncSession
from database.repositories import AdminRepository
from config import config

logger = logging.getLogger(__name__)

class AdminAuthMiddleware(BaseMiddleware):
    """Faqat tasdiqlangan faol administratorlarga ruxsat beruvchi middleware."""
    async def __call__(
        self,
        handler: Callable[[TelegramObject, Dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: Dict[str, Any]
    ) -> Any:
        user = data.get("event_from_user")
        if not user:
            return

        session: AsyncSession = data.get("session")
        if not session:
            return

        admin_repo = AdminRepository(session)
        is_admin = await admin_repo.is_admin(user.id)
        is_super = (user.id == config.SUPERADMIN_ID) or await admin_repo.is_superadmin(user.id)

        if not is_admin and not is_super:
            denied_msg = "⛔️ **Kechirasiz, sizda admin paneliga kirish huquqi yo'q!**"
            if isinstance(event, Message):
                await event.answer(denied_msg, parse_mode="Markdown")
            elif isinstance(event, CallbackQuery):
                await event.answer("Kechirasiz, sizda ushbu amalni bajarish huquqi yo'q!", show_alert=True)
            return

        data["is_superadmin"] = is_super
        return await handler(event, data)
