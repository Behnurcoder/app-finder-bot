# 📱 App Finder — Professional Telegram Bot

Professional, zamonaviy, xavfsiz va to'liq modulli arxitekturaga ega Telegram bot tizimi.
Ushbu bot orqali foydalanuvchilar turli xil ilovalarni (APK, dasturlar, havolalar) qidirishi, kategoriyalar bo'yicha saralashi, ilova ma'lumotlarini ko'rishi va xavfsiz yuklab olishi mumkin.

---

## 🌟 Asosiy imkoniyatlar

### 👤 Foydalanuvchilar uchun
- **📱 Ilovalar katalogi:** Sahifalarga ajratilgan (pagination) qulay ro'yxat, ilova kartasi (versiyasi, hajmi, platformasi, rasmi, tavsifi).
- **🔎 Ilova qidirish:** Katta-kichik harflar farqlanmaydigan (case-insensitive) to'liq yoki qismli substring qidiruv.
- **🗂 Kategoriyalar:** Ijtimoiy tarmoqlar, Video montaj, Ta'lim, Dizayn, Foydali dasturlar, O'yinlar va boshqalar.
- **🆕 Yangi ilovalar:** Eng so'nggi qo'shilgan versiyalar va dasturlar.
- **🔥 Mashhur ilovalar:** Yuklab olishlar soni bo'yicha saralangan eng sara ilovalar.
- **📥 Yuklab olish:** Telegram Bot API orqali to'g'ridan-to'g'ri fayl (APK) yuborish yoki tasdiqlangan rasmiy tashqi havolalar.
- **📩 Adminga murojaat:** Foydalanuvchilar bot orqali savol, taklif yoki shikoyat yo'llashi, admin javobini Telegram orqali qabul qilishi.
- **📢 Majburiy a'zolik tekshiruvi:** Belgilangan kanallarga a'zolik holati avtomatik tekshiriladi.

### 👑 Administratorlar paneli (`/admin`)
- **📊 To'liq statistika:** Jami foydalanuvchilar, bugungi yangi obunachilar, faol foydalanuvchilar, jami ilovalar, yuklab olishlar statistikasi, eng ommabop ilovalar, support chiptalari va adminlar soni.
- **➕ Ilova qo'shish (FSM Wizard):** Nomi, versiyasi, tavsifi, kategoriyasi, logotipi/rasmi, APK fayli yoki havolasi, platformasi, faollik holati va tasdiqlash oynasi (`[Saqlash] [Qayta kiritish] [Bekor qilish]`).
- **📱 Ilovalarni boshqarish:** Tahrirlash, yangi versiya qo'shish, ilovani vaqtincha yashirish yoki faollashtirish, o'chirish (tasdiqlash bilan).
- **👮 Adminlarni boshqarish (Faqat Superadmin):** Yangi admin qo'shish, huquqlarini belgilash, vaqtincha bloklash yoki adminlikni bekor qilish.
- **📢 Kanallarni boshqarish:** Asosiy kanallar, majburiy obuna kanallari va so'rovli (zayavka) kanallarni ulash, sozlash va o'chirish.
- **✉️ Foydalanuvchi xabarlari (Support chiptalari):** Barcha kelgan murojaatlar ro'yxati (Yangi, Ko'rib chiqilmoqda, Javob berildi, Yopildi), to'g'ridan-to'g'ri bot orqali foydalanuvchiga javob yo'llash.
- **📨 Bot orqali xabar yuborish (Broadcast):** Barcha foydalanuvchilarga yoki tanlangan Telegram ID ga matn yoki rasm+matn ko'rinishida e'lon tarqatish (flood control va xavfsiz rate limiting bilan).
- **🗂 Kategoriyalarni boshqarish:** Yangi kategoriya yaratish, emoji belgilash, tahrirlash yoki o'chirish.
- **⚙️ Bot sozlamalari:** Majburiy obunani yoqish/o'chirish, texnik tanaffus rejimini boshqarish.

---

## 🏗 Loyiha tuzilmasi

```text
app_finder/
│
├── bot.py                     # Botning asosiy kirish nuqtasi (startup, shutdown, dispatcher)
├── config.py                  # Konfiguratsiya va muhit o'zgaruvchilari (Config dataclass)
├── requirements.txt           # Kerakli Python kutubxonalari
├── .env.example               # Muhit o'zgaruvchilari namunasi
├── .gitignore                 # Git e'tibordan chetda qoldiradigan fayllar
├── alembic.ini                # Alembic migratsiya sozlamalari
├── README.md                  # Qo'llanma va hujjatlar
│
├── database/                  # Ma'lumotlar bazasi qatlami
│   ├── __init__.py
│   ├── database.py            # Async engine, sessionmaker va init_db
│   ├── models.py              # SQLAlchemy 2.0 ORM modellari
│   └── repositories.py        # CRUD Repository sinflari
│
├── handlers/                  # Bot hodisalarini qabul qiluvchi handlerlar
│   ├── __init__.py            # Main router
│   ├── start.py               # /start, /about, navigatsiya
│   ├── apps.py                # Katalog, ilova kartasi, yuklab olish
│   ├── search.py              # Qidiruv logikasi
│   ├── categories.py          # Kategoriyalar bo'yicha saralash
│   ├── subscriptions.py       # Obunani tekshirish
│   ├── support.py             # Foydalanuvchi murojaatlari
│   └── admin.py               # Professional admin panel
│
├── keyboards/                 # Tugmalar (Reply va Inline keyboards)
│   ├── __init__.py
│   ├── user.py                # Foydalanuvchi menyulari
│   └── admin.py               # Admin paneli tugmalari
│
├── middlewares/               # Aiogram vositachi qatlamlari
│   ├── __init__.py
│   ├── db_session.py          # Har bir so'rovga DB session taqdim etish
│   └── admin_auth.py          # Admin ruxsatlarini tekshirish
│
├── services/                  # Biznes mantiq (Service layer)
│   ├── __init__.py
│   ├── app_service.py         # Ilovalar bilan ishlash mantiqi
│   ├── channel_service.py     # Obunani tekshirish xizmati
│   ├── support_service.py     # Chiptalar va yozishmalar
│   ├── broadcast_service.py   # Rate-limited ommaviy xabarnomalar
│   └── statistics_service.py  # Dashboard statistika hisoboti
│
├── states/                    # FSM (Finite State Machine) holatlari
│   ├── __init__.py
│   ├── user_states.py
│   └── admin_states.py
│
├── utils/                     # Yordamchi vositalar va validatorlar
│   ├── __init__.py
│   ├── helpers.py             # Slugify, format_file_size, xavfsiz HTML
│   └── validators.py          # Kengaytma, URL, sarlavha tekshiruvlari
│
├── migrations/                # Alembic migratsiya skriptlari
│   ├── env.py
│   ├── script.py.mako
│   └── versions/
│       └── 001_initial_tables.py
│
└── tests/                     # Avtomatik testlar to'plami
    ├── __init__.py
    ├── test_validators.py
    ├── test_models_and_repos.py
    └── test_services.py
```

---

## 🛠 Texnologiyalar

- **Python 3.10+**
- **aiogram 3.x** — Asinxron Telegram Bot freymvorki
- **PostgreSQL** — Asosiy ma'lumotlar bazasi
- **SQLAlchemy 2.0 (Async)** — Zamonaviy ORM
- **asyncpg / aiosqlite** — Asinxron drayverlar
- **Alembic** — Database migratsiyalari
- **python-dotenv** — `.env` konfiguratsiya boshqaruvi
- **pytest & pytest-asyncio** — Avtomatlashtirilgan testlar

---

## 🚀 Windows PowerShell orqali ishga tushirish (Qadamma-qadam)

### 1-qadam: Python o'rnatilganini tekshirish
PowerShell oynasini oching va buyruqni kiriting:
```powershell
python --version
```
Agar Python 3.10 yoki undan yuqori versiya ko'rinsa, keyingi bosqichga o'ting. Aks holda [python.org](https://www.python.org/downloads/) saytidan yuklab olib, o'rnatish jarayonida **"Add Python to PATH"** katakchasini belgilang.

---

### 2-qadam: Loyiha papkasiga o'tish
```powershell
cd "C:\Users\NM\Desktop\apk bot"
```

---

### 3-qadam: Virtual muhit (venv) yaratish
Loyiha kutubxonalarini tizimdan alohida saqlash uchun virtual muhit yarating:
```powershell
python -m venv venv
```

---

### 4-qadam: Virtual muhitni faollashtirish
```powershell
.\venv\Scripts\Activate.ps1
```
> [!NOTE]
> Agar PowerShell skriptlarni ishga tushirish taqiqlanganligi haqida xato bersa (`Execution_Policies`), quyidagi buyruqni bering:
> `Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser`

---

### 5-qadam: Kutubxonalarni o'rnatish
```powershell
pip install --upgrade pip
pip install -r requirements.txt
```

---

### 6-qadam: PostgreSQL o'rnatish va ma'lumotlar bazasini yaratish
PostgreSQL serveringiz o'rnatilgan va ishlayotgan bo'lishi kerak.
`psql` terminali yoki pgAdmin orqali yangi baza yarating:
```sql
CREATE DATABASE app_finder_db;
```

---

### 7-qadam: `.env` konfiguratsiya faylini sozlash
`.env.example` nusxasini olib `.env` faylini hosil qiling:
```powershell
Copy-Item .env.example .env
```

`.env` faylini ochib, quyidagi parametrlarni to'ldiring:
1. `BOT_TOKEN`: Telegramda [@BotFather](https://t.me/BotFather) orqali yangi bot yaratib, olingan tokenni yozing.
2. `SUPERADMIN_ID`: O'zingizning Telegram ID raqamingizni yozing (ID raqamingizni [@userinfobot](https://t.me/userinfobot) orqali bilib olishingiz mumkin).
3. `DATABASE_URL`: PostgreSQL ulanish satrini kiriting. Masalan:
   ```env
   DATABASE_URL=postgresql+asyncpg://postgres:parolingiz@localhost:5432/app_finder_db
   ```
   *(Lokal test qilish uchun `sqlite+aiosqlite:///./app_finder.db` ham ishlatish mumkin)*

---

### 8-qadam: Ma'lumotlar bazasi migratsiyasini bajarish
Bazada barcha jadvallarni yaratish uchun Alembic migratsiyasini ishga tushiring:
```powershell
alembic upgrade head
```
*(Shuningdek bot birinchi ishga tushganda `init_db()` barcha jadvallarni avtomatik tekshirib, standart kategoriyalar va Superadmin hisobini kiritadi)*

---

### 9-qadam: Botni ishga tushirish
```powershell
python bot.py
```
Konsolda quyidagi kabi xabarni ko'rasiz:
```text
[INFO] Ma'lumotlar bazasi jadvallari muvaffaqiyatli tekshirildi/yaratildi.
[INFO] Bot long-polling orqali ishga tushmoqda...
```
Va superadminingiz Telegram profiliga bot ishga tushgani haqida xabarnoma keladi!

---

### 10-qadam: Avtomatik testlarni bajarish
Barcha komponentlar, modellar, validatorlar va xizmatlarni tekshirish uchun testlarni ishga tushiring:
```powershell
pytest -v
```

---

## 🐧 Serverga (Linux / Ubuntu) joylashtirish

### Systemd xizmat sifatida sozlash:
1. Serverda `/etc/systemd/system/app_finder.service` faylini yarating:
```ini
[Unit]
Description=App Finder Telegram Bot
After=network.target postgresql.service

[Service]
Type=simple
User=root
WorkingDirectory=/var/www/app_finder
ExecStart=/var/www/app_finder/venv/bin/python /var/www/app_finder/bot.py
Restart=always
RestartSec=5
EnvironmentFile=/var/www/app_finder/.env

[Install]
WantedBy=multi-user.target
```

2. Xizmatni yoqing va ishga tushiring:
```bash
sudo systemctl daemon-reload
sudo systemctl enable app_finder
sudo systemctl start app_finder
sudo systemctl status app_finder
```

---

## 🔒 Xavfsizlik qoidalari
- `.env` faylini va bot tokenini hech qachon ommaviy GitHub/Git repozitoriyasiga yuklamang.
- Superadmin hisobi faqat `.env` dagi `SUPERADMIN_ID` orqali beriladi, uni tashqaridan o'zgartirib bo'lmaydi.
- Admin amallari to'liq `admin_activity_logs` audit jadvaliga qayd etib boriladi.
- Ommaviy xabarlarda Telegram Flood Limitlariga qat'iy rioya qilinadi.
- Bot orqali faqat qonuniy va ruxsat berilgan dastur fayllari tarqatiladi.
