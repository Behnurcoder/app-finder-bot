import os
from dataclasses import dataclass
from typing import Optional
from dotenv import load_dotenv

# .env faylini yuklash
load_dotenv()

@dataclass(frozen=True)
class Config:
    BOT_TOKEN: str = os.getenv("BOT_TOKEN", "")
    SUPERADMIN_ID: int = int(os.getenv("SUPERADMIN_ID", "0"))
    DATABASE_URL: str = os.getenv("DATABASE_URL", "sqlite+aiosqlite:///./app_finder.db")
    USE_REDIS: bool = os.getenv("USE_REDIS", "false").lower() in ("true", "1", "yes")
    REDIS_URL: Optional[str] = os.getenv("REDIS_URL", "redis://localhost:6379/0")
    DEFAULT_PAGINATION_LIMIT: int = int(os.getenv("DEFAULT_PAGINATION_LIMIT", "6"))
    LOG_LEVEL: str = os.getenv("LOG_LEVEL", "INFO")

    @classmethod
    def load(cls) -> "Config":
        raw_db_url = os.getenv("DATABASE_URL", "sqlite+aiosqlite:///./app_finder.db")
        # Agar postgresql:// berilgan bo'lsa asyncpg driverga o'zgartirish
        if raw_db_url.startswith("postgresql://"):
            raw_db_url = raw_db_url.replace("postgresql://", "postgresql+asyncpg://", 1)
        
        superadmin_str = os.getenv("SUPERADMIN_ID", "0")
        try:
            superadmin_id = int(superadmin_str)
        except ValueError:
            superadmin_id = 0

        return cls(
            BOT_TOKEN=os.getenv("BOT_TOKEN", ""),
            SUPERADMIN_ID=superadmin_id,
            DATABASE_URL=raw_db_url,
            USE_REDIS=os.getenv("USE_REDIS", "false").lower() in ("true", "1", "yes"),
            REDIS_URL=os.getenv("REDIS_URL", "redis://localhost:6379/0"),
            DEFAULT_PAGINATION_LIMIT=int(os.getenv("DEFAULT_PAGINATION_LIMIT", "6")),
            LOG_LEVEL=os.getenv("LOG_LEVEL", "INFO")
        )

config = Config.load()
